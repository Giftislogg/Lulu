import 'track.dart';

class Playlist {
  final String id;
  final String title;
  final String description;
  final String coverUrl;
  final List<Track> tracks;
  final String colorHex;

  Playlist({
    required this.id,
    required this.title,
    required this.description,
    required this.coverUrl,
    required this.tracks,
    this.colorHex = '#6366f1',
  });

  factory Playlist.fromJson(Map<String, dynamic> json) {
    return Playlist(
      id: json['id'] as String? ?? '',
      title: json['title'] as String? ?? 'Untitled Playlist',
      description: json['description'] as String? ?? '',
      coverUrl: json['coverUrl'] as String? ?? '',
      colorHex: json['colorHex'] as String? ?? '#6366f1',
      tracks: (json['tracks'] as List<dynamic>? ?? [])
          .map((e) => Track.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'coverUrl': coverUrl,
      'colorHex': colorHex,
      'tracks': tracks.map((t) => t.toJson()).toList(),
    };
  }
}

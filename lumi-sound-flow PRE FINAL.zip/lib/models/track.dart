class Track {
  final String id;
  final String title;
  final String artist;
  final String album;
  final String coverUrl;
  final String? previewUrl;
  final int durationMs;
  final String? genre;
  bool isLiked;

  Track({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    required this.coverUrl,
    this.previewUrl,
    required this.durationMs,
    this.genre,
    this.isLiked = false,
  });

  String get durationFormatted {
    final seconds = (durationMs / 1000).floor();
    final mins = seconds ~/ 60;
    final remainingSecs = seconds % 60;
    return '$mins:${remainingSecs.toString().padLeft(2, '0')}';
  }

  factory Track.fromJson(Map<String, dynamic> json) {
    return Track(
      id: json['id'] as String? ?? UniqueKey().toString(),
      title: json['title'] as String? ?? json['name'] as String? ?? 'Unknown Title',
      artist: json['artist'] as String? ?? 
          (json['artists'] != null && (json['artists'] as List).isNotEmpty
              ? (json['artists'][0]['name'] as String? ?? 'Unknown Artist')
              : 'Unknown Artist'),
      album: json['album'] is Map 
          ? (json['album']['name'] as String? ?? 'Single')
          : (json['album'] as String? ?? 'Single'),
      coverUrl: json['coverUrl'] as String? ??
          (json['album'] is Map && json['album']['images'] != null && (json['album']['images'] as List).isNotEmpty
              ? (json['album']['images'][0]['url'] as String? ?? '')
              : 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80'),
      previewUrl: json['previewUrl'] as String? ?? json['preview_url'] as String?,
      durationMs: json['durationMs'] as int? ?? json['duration_ms'] as int? ?? 180000,
      genre: json['genre'] as String?,
      isLiked: json['isLiked'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'artist': artist,
      'album': album,
      'coverUrl': coverUrl,
      'previewUrl': previewUrl,
      'durationMs': durationMs,
      'genre': genre,
      'isLiked': isLiked,
    };
  }

  Track copyWith({
    String? id,
    String? title,
    String? artist,
    String? album,
    String? coverUrl,
    String? previewUrl,
    int? durationMs,
    String? genre,
    bool? isLiked,
  }) {
    return Track(
      id: id ?? this.id,
      title: title ?? this.title,
      artist: artist ?? this.artist,
      album: album ?? this.album,
      coverUrl: coverUrl ?? this.coverUrl,
      previewUrl: previewUrl ?? this.previewUrl,
      durationMs: durationMs ?? this.durationMs,
      genre: genre ?? this.genre,
      isLiked: isLiked ?? this.isLiked,
    );
  }
}

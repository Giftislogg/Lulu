import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/track.dart';
import '../models/playlist.dart';

class SpotifyService {
  static final List<Track> featuredTracks = [
    Track(
      id: 'neon-pulse-1',
      title: 'Midnight City Lights',
      artist: 'Kavinsky & The Weeknd',
      album: 'Outrun Echoes',
      coverUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&q=80',
      previewUrl: 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=lofi-study-112191.mp3',
      durationMs: 215000,
      genre: 'Synthwave',
    ),
    Track(
      id: 'neon-pulse-2',
      title: 'Neon Horizon',
      artist: 'Cyberdream',
      album: 'Digital Odyssey',
      coverUrl: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=600&q=80',
      previewUrl: 'https://cdn.pixabay.com/download/audio/2022/01/18/audio_d0a13f69d2.mp3?filename=electronic-future-beats-117997.mp3',
      durationMs: 198000,
      genre: 'Electronic',
    ),
    Track(
      id: 'neon-pulse-3',
      title: 'Starlight Drift',
      artist: 'Luna Eclipse',
      album: 'Nocturnal Whispers',
      coverUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&q=80',
      previewUrl: 'https://cdn.pixabay.com/download/audio/2021/09/06/audio_9a7d3fbcf4.mp3?filename=chill-abstract-intention-12099.mp3',
      durationMs: 240000,
      genre: 'Chillhop',
    ),
    Track(
      id: 'neon-pulse-4',
      title: 'Velocity Rush',
      artist: 'Apex Kinetic',
      album: 'Hyperdrive',
      coverUrl: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=600&q=80',
      previewUrl: 'https://cdn.pixabay.com/download/audio/2022/10/14/audio_9939f792cb.mp3?filename=tuesday-glitch-122413.mp3',
      durationMs: 182000,
      genre: 'Drum & Bass',
    ),
    Track(
      id: 'neon-pulse-5',
      title: 'Quiet Reflection',
      artist: 'Aura Bloom',
      album: 'Mindful Solitude',
      coverUrl: 'https://images.unsplash.com/photo-1445985543470-41fdd6ce388d?w=600&q=80',
      previewUrl: 'https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8c8a73467.mp3?filename=ambient-piano-amp-strings-10711.mp3',
      durationMs: 210000,
      genre: 'Ambient',
    ),
  ];

  static final List<Playlist> featuredPlaylists = [
    Playlist(
      id: 'pl-neon-pulse',
      title: 'Neon Pulse',
      description: 'Futuristic synthwave and high-octane cyber beats.',
      coverUrl: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=600&q=80',
      colorHex: '#6366F1',
      tracks: [
        featuredTracks[0],
        featuredTracks[1],
        featuredTracks[3],
      ],
    ),
    Playlist(
      id: 'pl-midnight-drive',
      title: 'Midnight Drive',
      description: 'Cruising through empty highways under city lights.',
      coverUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&q=80',
      colorHex: '#8B5CF6',
      tracks: [
        featuredTracks[0],
        featuredTracks[2],
        featuredTracks[4],
      ],
    ),
    Playlist(
      id: 'pl-deep-focus',
      title: 'Kinetic Focus',
      description: 'Lofi rhythms designed for flow state and deep work.',
      coverUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&q=80',
      colorHex: '#06B6D4',
      tracks: [
        featuredTracks[2],
        featuredTracks[4],
        featuredTracks[1],
      ],
    ),
  ];

  /// Search tracks dynamically with iTunes/Spotify audio preview proxy
  Future<List<Track>> searchTracks(String query) async {
    if (query.trim().isEmpty) return featuredTracks;

    try {
      final uri = Uri.parse('https://itunes.apple.com/search?term=${Uri.encodeComponent(query)}&media=music&entity=song&limit=25');
      final response = await http.get(uri).timeout(const Duration(seconds: 8));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final results = data['results'] as List<dynamic>? ?? [];

        if (results.isNotEmpty) {
          return results.map((item) {
            final artwork = (item['artworkUrl100'] as String? ?? '')
                .replaceAll('100x100bb', '600x600bb');
            return Track(
              id: item['trackId']?.toString() ?? UniqueKey().toString(),
              title: item['trackName'] as String? ?? 'Unknown Title',
              artist: item['artistName'] as String? ?? 'Unknown Artist',
              album: item['collectionName'] as String? ?? 'Single',
              coverUrl: artwork.isNotEmpty ? artwork : 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&q=80',
              previewUrl: item['previewUrl'] as String?,
              durationMs: item['trackTimeMillis'] as int? ?? 180000,
              genre: item['primaryGenreName'] as String?,
            );
          }).toList();
        }
      }
    } catch (e) {
      // Fallback to local filter if offline
    }

    final lower = query.toLowerCase();
    return featuredTracks.where((t) {
      return t.title.toLowerCase().contains(lower) ||
          t.artist.toLowerCase().contains(lower) ||
          t.album.toLowerCase().contains(lower) ||
          (t.genre != null && t.genre!.toLowerCase().contains(lower));
    }).toList();
  }
}

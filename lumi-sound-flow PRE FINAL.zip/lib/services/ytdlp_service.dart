import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../models/track.dart';
import '../models/playlist.dart';
import 'spotify_service.dart';

class YtDlpService {
  static final List<Track> featuredTracks = SpotifyService.featuredTracks;
  static final List<Playlist> featuredPlaylists = SpotifyService.featuredPlaylists;

  /// Search tracks utilizing the Lumi yt-dlp discovery engine with fallback
  Future<List<Track>> searchTracks(String query) async {
    final service = SpotifyService();
    return await service.searchTracks(query);
  }
}

import 'dart:async';
import 'package:just_audio/just_audio.dart';
import '../models/track.dart';

enum AudioPlayerState { stopped, loading, playing, paused, completed }

class AudioPlayerService {
  static final AudioPlayerService _instance = AudioPlayerService._internal();
  factory AudioPlayerService() => _instance;

  final AudioPlayer _player = AudioPlayer();
  AudioPlayer get player => _player;

  Track? _currentTrack;
  Track? get currentTrack => _currentTrack;

  AudioPlayerState _state = AudioPlayerState.stopped;
  AudioPlayerState get state => _state;

  final _stateController = StreamController<AudioPlayerState>.broadcast();
  Stream<AudioPlayerState> get stateStream => _stateController.stream;

  final _trackController = StreamController<Track?>.broadcast();
  Stream<Track?> get trackStream => _trackController.stream;

  AudioPlayerService._internal() {
    _initListener();
  }

  void _initListener() {
    _player.playerStateStream.listen((playerState) {
      if (playerState.processingState == ProcessingState.loading ||
          playerState.processingState == ProcessingState.buffering) {
        _state = AudioPlayerState.loading;
      } else if (playerState.playing) {
        _state = AudioPlayerState.playing;
      } else if (playerState.processingState == ProcessingState.completed) {
        _state = AudioPlayerState.completed;
      } else {
        _state = AudioPlayerState.paused;
      }
      _stateController.add(_state);
    });
  }

  Future<void> playTrack(Track track) async {
    _currentTrack = track;
    _trackController.add(_currentTrack);

    final url = track.previewUrl;
    if (url != null && url.isNotEmpty) {
      try {
        _state = AudioPlayerState.loading;
        _stateController.add(_state);
        await _player.setUrl(url);
        await _player.play();
      } catch (e) {
        // Fallback default stream if URL has expired
        await _player.setUrl(
            'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=lofi-study-112191.mp3');
        await _player.play();
      }
    } else {
      // Fallback preview
      await _player.setUrl(
          'https://cdn.pixabay.com/download/audio/2022/01/18/audio_d0a13f69d2.mp3?filename=electronic-future-beats-117997.mp3');
      await _player.play();
    }
  }

  Future<void> pause() async {
    await _player.pause();
  }

  Future<void> resume() async {
    await _player.play();
  }

  Future<void> seek(Duration position) async {
    await _player.seek(position);
  }

  Future<void> setVolume(double volume) async {
    await _player.setVolume(volume.clamp(0.0, 1.0));
  }

  void dispose() {
    _stateController.close();
    _trackController.close();
    _player.dispose();
  }
}

import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/lumi_mascot.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String _audioQuality = 'High (320kbps)';
  bool _normalizeVolume = true;
  bool _gaplessPlayback = true;
  bool _aiSynthesisFallback = true;
  String _equalizerPreset = 'Electronic / Bass+';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 100),
          children: [
            const Text(
              'Settings',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w800,
                color: AppColors.textPrimary,
                letterSpacing: -0.5,
              ),
            ),
            const SizedBox(height: 20),

            // Profile & Tier Card
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.card,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: AppColors.border),
              ),
              child: const Row(
                children: [
                  LumiMascot(size: 48),
                  SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Lumi Premium User',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'Unlimited streaming • Offline Active',
                          style: TextStyle(fontSize: 12, color: AppColors.textMuted),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),
            const Text(
              'AUDIO PLAYBACK',
              style: TextStyle(
                color: AppColors.textMuted,
                fontSize: 11,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.2,
              ),
            ),
            const SizedBox(height: 10),

            Container(
              decoration: BoxDecoration(
                color: AppColors.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                children: [
                  ListTile(
                    title: const Text('Streaming Quality', style: TextStyle(fontSize: 14)),
                    subtitle: Text(_audioQuality, style: const TextStyle(color: AppColors.primary, fontSize: 12)),
                    trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: AppColors.textMuted),
                    onTap: () {
                      showModalBottomSheet(
                        context: context,
                        backgroundColor: AppColors.surfaceElevated,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                        ),
                        builder: (ctx) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 20),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: ['Automatic', 'Normal (160kbps)', 'High (320kbps)', 'Lossless (FLAC)']
                                .map((q) => ListTile(
                                      title: Text(q),
                                      trailing: _audioQuality == q ? const Icon(Icons.check, color: AppColors.primary) : null,
                                      onTap: () {
                                        setState(() => _audioQuality = q);
                                        Navigator.pop(ctx);
                                      },
                                    ))
                                .toList(),
                          ),
                        ),
                      );
                    },
                  ),
                  const Divider(color: AppColors.border, height: 1),
                  ListTile(
                    title: const Text('Equalizer Preset', style: TextStyle(fontSize: 14)),
                    subtitle: Text(_equalizerPreset, style: const TextStyle(color: AppColors.primary, fontSize: 12)),
                    trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: AppColors.textMuted),
                    onTap: () {
                      showModalBottomSheet(
                        context: context,
                        backgroundColor: AppColors.surfaceElevated,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                        ),
                        builder: (ctx) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 20),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: ['Flat', 'Bass Boost', 'Electronic / Bass+', 'Vocal Clarity', 'Acoustic']
                                .map((eq) => ListTile(
                                      title: Text(eq),
                                      trailing: _equalizerPreset == eq ? const Icon(Icons.check, color: AppColors.primary) : null,
                                      onTap: () {
                                        setState(() => _equalizerPreset = eq);
                                        Navigator.pop(ctx);
                                      },
                                    ))
                                .toList(),
                          ),
                        ),
                      );
                    },
                  ),
                  const Divider(color: AppColors.border, height: 1),
                  SwitchListTile(
                    activeColor: AppColors.primary,
                    title: const Text('Volume Normalization', style: TextStyle(fontSize: 14)),
                    subtitle: const Text('Keep sound output consistent across tracks', style: TextStyle(fontSize: 12, color: AppColors.textMuted)),
                    value: _normalizeVolume,
                    onChanged: (val) => setState(() => _normalizeVolume = val),
                  ),
                  const Divider(color: AppColors.border, height: 1),
                  SwitchListTile(
                    activeColor: AppColors.primary,
                    title: const Text('Gapless Playback', style: TextStyle(fontSize: 14)),
                    subtitle: const Text('Seamless transitions between queued tracks', style: TextStyle(fontSize: 12, color: AppColors.textMuted)),
                    value: _gaplessPlayback,
                    onChanged: (val) => setState(() => _gaplessPlayback = val),
                  ),
                  const Divider(color: AppColors.border, height: 1),
                  SwitchListTile(
                    activeColor: AppColors.primary,
                    title: const Text('AI Audio Synthesizer Fallback', style: TextStyle(fontSize: 14)),
                    subtitle: const Text('Auto-generate synth tones if track preview is restricted', style: TextStyle(fontSize: 12, color: AppColors.textMuted)),
                    value: _aiSynthesisFallback,
                    onChanged: (val) => setState(() => _aiSynthesisFallback = val),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),
            const Text(
              'STORAGE & DATA',
              style: TextStyle(
                color: AppColors.textMuted,
                fontSize: 11,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.2,
              ),
            ),
            const SizedBox(height: 10),

            Container(
              decoration: BoxDecoration(
                color: AppColors.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                children: [
                  ListTile(
                    title: const Text('Clear Audio Cache', style: TextStyle(fontSize: 14)),
                    subtitle: const Text('Cached streams: 42.8 MB', style: TextStyle(fontSize: 12, color: AppColors.textMuted)),
                    trailing: TextButton(
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Audio cache cleared successfully')),
                        );
                      },
                      child: const Text('Clear', style: TextStyle(color: AppColors.error)),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 30),
            const Center(
              child: Column(
                children: [
                  Text(
                    'Lumi for Android • v1.0.0 (Native Flutter Build)',
                    style: TextStyle(color: AppColors.textMuted, fontSize: 12),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'Built with Flutter, JustAudio & Spotify API',
                    style: TextStyle(color: AppColors.textMuted, fontSize: 11),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

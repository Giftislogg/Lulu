import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class LumiMascot extends StatefulWidget {
  final double size;
  final bool isGlowing;

  const LumiMascot({
    super.key,
    this.size = 48,
    this.isGlowing = true,
  });

  @override
  State<LumiMascot> createState() => _LumiMascotState();
}

class _LumiMascotState extends State<LumiMascot> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        final glowScale = 1.0 + (_controller.value * 0.15);
        return Container(
          width: widget.size,
          height: widget.size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              colors: [AppColors.primary, AppColors.secondary],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: widget.isGlowing
                ? [
                    BoxShadow(
                      color: AppColors.primary.withOpacity(0.4 * glowScale),
                      blurRadius: 16 * glowScale,
                      spreadRadius: 2,
                    ),
                  ]
                : [],
          ),
          child: ClipOval(
            child: Image.asset(
              'public/lumi_logo-removebg-preview.png',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const Icon(
                Icons.music_note_rounded,
                color: Colors.white,
                size: 26,
              ),
            ),
          ),
        );
      },
    );
  }
}

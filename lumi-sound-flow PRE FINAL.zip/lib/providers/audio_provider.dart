import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import '../models/track.dart';
import '../services/audio_player_service.dart';

enum RepeatMode { off, all, one }

class AudioProvider extends ChangeNotifier {
  final AudioPlayerService _audioService = AudioPlayerService();
  
  Track? _currentTrack;
  Track? get currentTrack => _currentTrack;

  bool _isPlaying = false;
  bool get isPlaying => _isPlaying;

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  Duration _position = Duration.zero;
  Duration get position => _position;

  Duration _duration = Duration.zero;
  Duration get duration => _duration;

  double _volume = 0.8;
  double get volume => _volume;

  bool _isShuffle = false;
  bool get isShuffle => _isShuffle;

  RepeatMode _repeatMode = RepeatMode.off;
  RepeatMode get repeatMode => _repeatMode;

  List<Track> _queue = [];
  List<Track> get queue => _queue;
  int _currentIndex = -1;
  int get currentIndex => _currentIndex;

  AudioProvider() {
    _initStreams();
  }

  void _initStreams() {
    _audioService.player.playerStateStream.listen((state) {
      _isPlaying = state.playing;
      _isLoading = state.processingState == ProcessingState.loading ||
          state.processingState == ProcessingState.buffering;

      if (state.processingState == ProcessingState.completed) {
        if (_repeatMode == RepeatMode.one) {
          seek(Duration.zero);
          play();
        } else {
          next();
        }
      }
      notifyListeners();
    });

    _audioService.player.positionStream.listen((pos) {
      _position = pos;
      notifyListeners();
    });

    _audioService.player.durationStream.listen((dur) {
      if (dur != null) {
        _duration = dur;
        notifyListeners();
      }
    });
  }

  void setQueue(List<Track> tracks, {int startIndex = 0}) {
    _queue = List.from(tracks);
    if (_queue.isNotEmpty && startIndex >= 0 && startIndex < _queue.length) {
      _currentIndex = startIndex;
      playTrack(_queue[_currentIndex]);
    }
  }

  void addToQueue(Track track) {
    _queue.add(track);
    if (_currentTrack == null) {
      _currentIndex = 0;
      playTrack(track);
    }
    notifyListeners();
  }

  Future<void> playTrack(Track track) async {
    _currentTrack = track;
    _currentIndex = _queue.indexWhere((t) => t.id == track.id);
    if (_currentIndex == -1) {
      _queue.add(track);
      _currentIndex = _queue.length - 1;
    }
    await _audioService.playTrack(track);
    notifyListeners();
  }

  Future<void> togglePlayPause() async {
    if (_isPlaying) {
      await _audioService.pause();
    } else {
      if (_currentTrack != null) {
        await _audioService.resume();
      } else if (_queue.isNotEmpty) {
        playTrack(_queue.first);
      }
    }
  }

  Future<void> play() async => await _audioService.resume();
  Future<void> pause() async => await _audioService.pause();

  Future<void> seek(Duration pos) async {
    _position = pos;
    notifyListeners();
    await _audioService.seek(pos);
  }

  Future<void> setVolume(double val) async {
    _volume = val;
    notifyListeners();
    await _audioService.setVolume(val);
  }

  void toggleShuffle() {
    _isShuffle = !_isShuffle;
    notifyListeners();
  }

  void cycleRepeatMode() {
    if (_repeatMode == RepeatMode.off) {
      _repeatMode = RepeatMode.all;
    } else if (_repeatMode == RepeatMode.all) {
      _repeatMode = RepeatMode.one;
    } else {
      _repeatMode = RepeatMode.off;
    }
    notifyListeners();
  }

  void next() {
    if (_queue.isEmpty) return;
    if (_currentIndex < _queue.length - 1) {
      _currentIndex++;
      playTrack(_queue[_currentIndex]);
    } else if (_repeatMode == RepeatMode.all) {
      _currentIndex = 0;
      playTrack(_queue[_currentIndex]);
    }
  }

  void previous() {
    if (_position.inSeconds > 3) {
      seek(Duration.zero);
      return;
    }
    if (_currentIndex > 0) {
      _currentIndex--;
      playTrack(_queue[_currentIndex]);
    } else {
      seek(Duration.zero);
    }
  }
}

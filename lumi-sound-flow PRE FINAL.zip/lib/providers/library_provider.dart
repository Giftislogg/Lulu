import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/track.dart';
import '../models/playlist.dart';
import '../services/spotify_service.dart';

class LibraryProvider extends ChangeNotifier {
  final List<Track> _likedTracks = [];
  List<Track> get likedTracks => _likedTracks;

  final List<Playlist> _customPlaylists = [];
  List<Playlist> get customPlaylists => _customPlaylists;

  final List<Track> _recentlyPlayed = [];
  List<Track> get recentlyPlayed => _recentlyPlayed;

  final List<String> _recentSearches = ['Synthwave', 'Midnight Drive', 'Cyberpunk', 'Lofi Study'];
  List<String> get recentSearches => _recentSearches;

  LibraryProvider() {
    _loadFromStorage();
  }

  Future<void> _loadFromStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      
      final likedJson = prefs.getString('lumi_liked_tracks');
      if (likedJson != null) {
        final list = json.decode(likedJson) as List<dynamic>;
        _likedTracks.clear();
        _likedTracks.addAll(list.map((e) => Track.fromJson(e as Map<String, dynamic>)));
      } else {
        _likedTracks.addAll([
          SpotifyService.featuredTracks[0],
          SpotifyService.featuredTracks[1],
        ]);
      }

      final playlistsJson = prefs.getString('lumi_custom_playlists');
      if (playlistsJson != null) {
        final list = json.decode(playlistsJson) as List<dynamic>;
        _customPlaylists.clear();
        _customPlaylists.addAll(list.map((e) => Playlist.fromJson(e as Map<String, dynamic>)));
      }

      notifyListeners();
    } catch (e) {
      debugPrint('Error loading library: $e');
    }
  }

  Future<void> _saveToStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(
        'lumi_liked_tracks',
        json.encode(_likedTracks.map((t) => t.toJson()).toList()),
      );
      await prefs.setString(
        'lumi_custom_playlists',
        json.encode(_customPlaylists.map((p) => p.toJson()).toList()),
      );
    } catch (e) {
      debugPrint('Error saving library: $e');
    }
  }

  bool isTrackLiked(String trackId) {
    return _likedTracks.any((t) => t.id == trackId);
  }

  void toggleLike(Track track) {
    final index = _likedTracks.indexWhere((t) => t.id == track.id);
    if (index >= 0) {
      _likedTracks.removeAt(index);
    } else {
      final updated = track.copyWith(isLiked: true);
      _likedTracks.insert(0, updated);
    }
    _saveToStorage();
    notifyListeners();
  }

  void addRecentlyPlayed(Track track) {
    _recentlyPlayed.removeWhere((t) => t.id == track.id);
    _recentlyPlayed.insert(0, track);
    if (_recentlyPlayed.length > 20) {
      _recentlyPlayed.removeLast();
    }
    notifyListeners();
  }

  void addSearchQuery(String query) {
    final trimmed = query.trim();
    if (trimmed.isEmpty) return;
    _recentSearches.remove(trimmed);
    _recentSearches.insert(0, trimmed);
    if (_recentSearches.length > 10) {
      _recentSearches.removeLast();
    }
    notifyListeners();
  }

  void clearRecentSearches() {
    _recentSearches.clear();
    notifyListeners();
  }

  void createPlaylist(String title, String description) {
    final newPlaylist = Playlist(
      id: 'pl_${DateTime.now().millisecondsSinceEpoch}',
      title: title,
      description: description,
      coverUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&q=80',
      colorHex: '#A855F7',
      tracks: [],
    );
    _customPlaylists.insert(0, newPlaylist);
    _saveToStorage();
    notifyListeners();
  }

  void addTrackToPlaylist(String playlistId, Track track) {
    final index = _customPlaylists.indexWhere((p) => p.id == playlistId);
    if (index >= 0) {
      final pl = _customPlaylists[index];
      if (!pl.tracks.any((t) => t.id == track.id)) {
        pl.tracks.add(track);
        _saveToStorage();
        notifyListeners();
      }
    }
  }

  void deletePlaylist(String playlistId) {
    _customPlaylists.removeWhere((p) => p.id == playlistId);
    _saveToStorage();
    notifyListeners();
  }
}

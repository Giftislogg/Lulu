import { createFileRoute, Link } from "@tanstack/react-router";
import { Zap, Rocket, Sparkles, UserCheck } from "lucide-react";
import { LumiMascot } from "@/components/lumi/LumiMascot";
import { useUser } from "@/hooks/useUser";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Lumi — Fastest Offline Music Downloader & Overlay Player" },
      {
        name: "description",
        content:
          "Lumi is an intelligent Android music player with Turbo Sync downloads, a system-wide floating overlay and volume-key shortcuts.",
      },
      { property: "og:title", content: "Lumi — Turbo Sync Music Engine" },
      {
        property: "og:description",
        content:
          "Download lossless audio instantly, play offline and control music from a floating overlay over any app.",
      },
    ],
  }),
  component: Welcome,
});

function Welcome() {
  const { username, setUsername } = useUser();

  return (
    <div className="relative min-h-screen bg-background">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-96 ambient-glow" />
      <div className="relative mx-auto flex min-h-screen w-full max-w-md flex-col justify-center px-6 py-12">
        {/* Lumi Character Mascot Hero Spotlight */}
        <div className="relative mx-auto mb-6 flex flex-col items-center">
          <div className="relative flex items-center justify-center">
            <div className="absolute size-48 rounded-full bg-primary/30 blur-2xl animate-pulse" />
            <div className="relative flex h-48 w-48 items-center justify-center transition-transform hover:scale-105 drop-shadow-[0_12px_24px_rgba(0,0,0,0.15)]">
              <LumiMascot className="h-full w-full" alt="Lumi Character Logo" />
            </div>
            <div className="absolute -bottom-3 flex items-center gap-1.5 rounded-full bg-primary px-3.5 py-1 text-xs font-black uppercase tracking-widest text-primary-foreground shadow-md">
              <Sparkles className="size-3.5 fill-primary-foreground" />
              Lumi Sound Guide
            </div>
          </div>
        </div>

        <div className="inline-flex w-fit items-center gap-2 rounded-full bg-secondary px-4 py-2 text-xs font-bold tracking-widest text-ink mx-auto sm:mx-0">
          <Zap className="size-4 text-lime-deep" />
          ENGINE V2.0 LIVE
        </div>

        <h1 className="mt-5 text-5xl leading-[0.95] font-extrabold text-ink text-center sm:text-left">
          Welcome to
          <br />
          <span className="text-lime-deep drop-shadow-[0_0_24px_oklch(0.89_0.24_124/0.55)]">
            Lumi
          </span>
        </h1>

        <p className="mt-4 text-base leading-relaxed text-muted-foreground text-center sm:text-left">
          The fastest app to download music with. Harness the power of the Turbo Sync core for
          instant, lossless audio delivery.
        </p>

        {/* Username Selection Card */}
        <div className="card-soft mt-6 p-4">
          <label
            htmlFor="username-input"
            className="block text-xs font-extrabold uppercase tracking-wider text-muted-foreground"
          >
            What should we call you?
          </label>
          <div className="relative mt-2 flex items-center">
            <input
              id="username-input"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              maxLength={10}
              placeholder="Your name"
              className="w-full rounded-2xl border border-border bg-background px-4 py-3 text-base font-bold text-ink placeholder:text-muted-foreground focus:border-primary focus:outline-none"
            />
            <span className="absolute right-3.5 text-xs font-bold text-muted-foreground">
              {username.length}/10
            </span>
          </div>
          <p className="mt-2 text-xs font-medium text-muted-foreground flex items-center gap-1">
            <UserCheck className="size-3.5 text-lime-deep shrink-0" />
            App will greet you as{" "}
            <span className="font-bold text-ink">Hello, {username || "Mark"}!</span>
          </p>
        </div>

        <Link
          to="/home"
          className="glow-lime mt-6 inline-flex items-center justify-center gap-3 rounded-full bg-primary px-8 py-4 text-base font-extrabold tracking-wide text-primary-foreground transition-transform active:scale-[0.98]"
        >
          <Rocket className="size-5" />
          ENTER ENGINE
        </Link>

        <Link
          to="/how-it-works"
          className="mt-3 inline-flex w-fit items-center justify-center rounded-full bg-card px-8 py-3.5 text-base font-bold text-ink shadow-[var(--shadow-soft)] mx-auto sm:mx-0"
        >
          How it works
        </Link>

        <div className="mt-12 flex justify-center">
          <div className="relative flex size-60 items-center justify-center rounded-full border border-dashed border-primary/50">
            <div className="flex size-48 flex-col items-center justify-center gap-2 rounded-full border border-primary/40 bg-accent/40 text-center p-3">
              <div className="glow-lime flex size-16 items-center justify-center rounded-full border-2 border-primary bg-card/80 p-1">
                <LumiMascot className="size-full" alt="Lumi Character Logo" />
              </div>
              <div>
                <p className="text-lg font-bold text-ink">Turbo Sync</p>
                <p className="text-xs font-semibold text-lime-deep">Status: Active</p>
              </div>
              <div className="h-2 w-28 overflow-hidden rounded-full bg-secondary">
                <div className="h-full w-3/4 rounded-full bg-primary" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowLeft,
  UserRound,
  Zap,
  Power,
  Volume2,
  Volume1,
  Search,
  Rocket,
  Link2,
} from "lucide-react";
import { PhoneShell } from "@/components/lumi/PhoneShell";

export const Route = createFileRoute("/how-it-works")({
  head: () => ({
    meta: [
      { title: "Engine Manual — How Lumi Overlay Works" },
      {
        name: "description",
        content:
          "Four phases: activate the engine, trigger the overlay with volume keys, instant sync a track ID and hit turbo throughput.",
      },
      { property: "og:title", content: "Lumi Engine Manual" },
      {
        property: "og:description",
        content: "Master the high-speed download workflow in four simple phases.",
      },
    ],
  }),
  component: HowItWorks,
});

const phases = [
  {
    n: "01",
    title: "Activate the Engine",
    body: "Toggle the primary ignition switch on the dashboard to prime the downloader for background monitoring.",
    icon: <Power className="size-6 text-lime-deep" />,
  },
  {
    n: "02",
    title: "Trigger Overlay",
    body: "Strike volume up or down from any app. The engine listens globally to summon the HUD.",
    icon: (
      <div className="flex gap-2">
        <span className="flex size-11 items-center justify-center rounded-full border border-primary">
          <Volume2 className="size-5 text-lime-deep" />
        </span>
        <span className="flex size-11 items-center justify-center rounded-full border border-primary">
          <Volume1 className="size-5 text-lime-deep" />
        </span>
      </div>
    ),
  },
  {
    n: "03",
    title: "Instant Sync",
    body: "Drop the track ID into the terminal field. The glass HUD validates the target instantly.",
    icon: (
      <span className="glow-lime flex size-12 items-center justify-center rounded-full bg-primary">
        <Search className="size-5 text-primary-foreground" />
      </span>
    ),
    field: true,
  },
  {
    n: "04",
    title: "Turbo Throughput",
    body: "Watch the gauge max out as multi-threaded downloaders pull the file into your local library.",
    icon: <Rocket className="size-6 text-lime-deep" />,
    gauge: true,
  },
];

function HowItWorks() {
  return (
    <PhoneShell
      header={
        <div className="flex items-center justify-between">
          <Link to="/" aria-label="Back" className="text-ink">
            <ArrowLeft className="size-6" />
          </Link>
          <span className="text-xl font-extrabold tracking-wide text-lime-deep">LUMI</span>
          <span className="flex size-10 items-center justify-center rounded-full bg-secondary text-ink">
            <UserRound className="size-5" />
          </span>
        </div>
      }
    >
      <div className="flex flex-col items-center text-center">
        <span className="flex size-20 items-center justify-center rounded-full bg-secondary">
          <Zap className="size-9 fill-primary text-lime-deep" />
        </span>
        <h1 className="mt-5 text-5xl font-extrabold text-ink">Engine Manual</h1>
        <p className="mt-3 text-lg text-muted-foreground">
          Master the high-speed download workflow in four simple phases.
        </p>
      </div>

      <div className="mt-8 space-y-6">
        {phases.map((p) => (
          <section key={p.n} className="card-soft p-6">
            <div className="flex items-start justify-between gap-4">
              <span className="text-3xl font-extrabold text-primary">{p.n}</span>
              {p.icon}
            </div>
            <h2 className="mt-4 text-2xl font-bold text-ink">{p.title}</h2>
            <p className="mt-2 text-base leading-relaxed text-muted-foreground">{p.body}</p>

            {p.field ? (
              <div className="mt-5 flex items-center gap-2 rounded-full bg-secondary px-5 py-3.5 text-muted-foreground">
                <Link2 className="size-4" />
                <span className="text-base">Paste link here...</span>
              </div>
            ) : null}

            {p.gauge ? (
              <div className="mt-5">
                <div className="flex items-center justify-between text-sm font-bold">
                  <span className="tracking-widest text-muted-foreground">THROUGHPUT</span>
                  <span className="text-ink">MAX</span>
                </div>
                <div className="mt-2 h-3 overflow-hidden rounded-full bg-secondary">
                  <div className="h-full w-[88%] rounded-full bg-primary" />
                </div>
              </div>
            ) : null}
          </section>
        ))}
      </div>
    </PhoneShell>
  );
}

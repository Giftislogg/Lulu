import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import {
  HelpCircle,
  Bell,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Zap,
  BarChart3,
  Rocket,
  Plus,
  Tv,
  Sparkles,
  AlertTriangle,
  X,
  CheckCircle2,
  Lock,
  Download,
  Loader2,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { PhoneShell, SectionTitle } from "@/components/lumi/PhoneShell";
import { LumiMascot } from "@/components/lumi/LumiMascot";
import { Switch } from "@/components/ui/switch";
import { covers } from "@/data/lumi";
import { useUser } from "@/hooks/useUser";
import { useTriggers } from "@/hooks/useTriggers";
import { useAudio } from "@/context/AudioContext";
import { useDownloads } from "@/context/DownloadContext";
import { TrackItem } from "@/lib/spotify";
import { getChartFn } from "@/lib/server-functions";

const DEFAULT_DAILY_MIX: TrackItem[] = [
  {
    id: "0VjIjW4GlUZAMYd2vXMi3b",
    title: "Blinding Lights",
    artist: "The Weeknd",
    artists: ["The Weeknd"],
    cover: "https://i.scdn.co/image/ab67616d0000b27388638622e2004b9e30a43651",
    quality: "320kbps Lossless",
    size: "7.8MB",
    sync: "0.2s",
    duration: "3:20",
    duration_ms: 200040,
    preview_url: null,
    url: "",
    uri: "",
    explicit: false,
  },
  {
    id: "4D2t2A2kM2A2kM2A2kM2A2",
    title: "As It Was",
    artist: "Harry Styles",
    artists: ["Harry Styles"],
    cover: "https://i.scdn.co/image/ab67616d0000b273b46f74097655d0f353caab14",
    quality: "320kbps Lossless",
    size: "6.9MB",
    sync: "0.2s",
    duration: "2:47",
    duration_ms: 167303,
    preview_url: null,
    url: "",
    uri: "",
    explicit: false,
  },
  {
    id: "7qiZ22S2P38SuS3E2EV32R",
    title: "Shape of You",
    artist: "Ed Sheeran",
    artists: ["Ed Sheeran"],
    cover: "https://i.scdn.co/image/ab67616d0000b273ba5d94a44c92f53baf671295",
    quality: "320kbps Lossless",
    size: "8.2MB",
    sync: "0.3s",
    duration: "3:53",
    duration_ms: 233712,
    preview_url: null,
    url: "",
    uri: "",
    explicit: false,
  },
];

const DEFAULT_TURBO_PICKS: TrackItem[] = [
  {
    id: "748259425425",
    title: "Starboy",
    artist: "The Weeknd",
    artists: ["The Weeknd", "Daft Punk"],
    cover: "https://i.scdn.co/image/ab67616d0000b2734718e24126281412822830f5",
    quality: "320kbps Lossless",
    size: "9.1MB",
    sync: "0.2s",
    duration: "3:50",
    duration_ms: 230400,
    preview_url: null,
    url: "",
    uri: "",
    explicit: false,
  },
  {
    id: "859239582938",
    title: "Levitating",
    artist: "Dua Lipa",
    artists: ["Dua Lipa"],
    cover: "https://i.scdn.co/image/ab67616d0000b273bd26ed1081541818227b2a6d",
    quality: "320kbps Lossless",
    size: "8.1MB",
    sync: "0.3s",
    duration: "3:23",
    duration_ms: 203000,
    preview_url: null,
    url: "",
    uri: "",
    explicit: false,
  },
  {
    id: "928349283492",
    title: "Flowers",
    artist: "Miley Cyrus",
    artists: ["Miley Cyrus"],
    cover: "https://i.scdn.co/image/ab67616d0000b273f429549123d038222b3145d2",
    quality: "320kbps Lossless",
    size: "7.9MB",
    sync: "0.1s",
    duration: "3:20",
    duration_ms: 200000,
    preview_url: null,
    url: "",
    uri: "",
    explicit: false,
  },
];

export const Route = createFileRoute("/home")({
  head: () => ({
    meta: [
      { title: "Lumi Dashboard — Engine Status & Daily Mix" },
      {
        name: "description",
        content:
          "Toggle the Lumi engine, arm volume-key triggers and jump back into recently played tracks and Turbo Picks.",
      },
      { property: "og:title", content: "Lumi Dashboard" },
      {
        property: "og:description",
        content: "Engine status, volume-key triggers, daily mix and Turbo Picks in one place.",
      },
    ],
  }),
  component: HomeScreen,
});

function HomeScreen() {
  const { username } = useUser();
  const { triggerBalance, maxTriggers, addOneTrigger, consumeTrigger } = useTriggers();
  const {
    currentTrack,
    isPlaying,
    playTrack,
    togglePlayPause,
    setIsPlayerModalOpen,
    recentlyPlayedHistory,
  } = useAudio();
  const { isDownloading, isDownloaded, startDownload } = useDownloads();

  const [dailyMixTracks, setDailyMixTracks] = useState<TrackItem[]>(DEFAULT_DAILY_MIX);
  const [turboPicksTracks, setTurboPicksTracks] = useState<TrackItem[]>(DEFAULT_TURBO_PICKS);

  useEffect(() => {
    let active = true;
    getChartFn({ data: { key: "top-50-global", limit: 10 } })
      .then((res) => {
        if (active && res && res.length > 0) {
          setDailyMixTracks(res);
        }
      })
      .catch(() => {});

    getChartFn({ data: { key: "viral-50-global", limit: 6 } })
      .then((res) => {
        if (active && res && res.length > 0) {
          setTurboPicksTracks(res);
        }
      })
      .catch(() => {});

    return () => {
      active = false;
    };
  }, []);

  const [engine, setEngine] = useState(true);
  const [volUp, setVolUp] = useState(true);
  const [volDown, setVolDown] = useState(false);

  // Modals state
  const [showRanOutModal, setShowRanOutModal] = useState(false);
  const [showAdModal, setShowAdModal] = useState(false);

  // Ad simulation state
  const [isWatchingAd, setIsWatchingAd] = useState(false);
  const [adCountdown, setAdCountdown] = useState(3);
  const [adSuccessMessage, setAdSuccessMessage] = useState(false);

  // Trigger feedback toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Handle Vol Up toggle
  const handleVolUpToggle = (checked: boolean) => {
    if (checked) {
      if (triggerBalance <= 0) {
        setVolUp(false);
        setShowRanOutModal(true);
        return;
      }
      setVolUp(true);
      showToast("Vol Up Trigger armed!");
    } else {
      setVolUp(false);
    }
  };

  // Handle Vol Down toggle
  const handleVolDownToggle = (checked: boolean) => {
    if (checked) {
      if (triggerBalance <= 0) {
        setVolDown(false);
        setShowRanOutModal(true);
        return;
      }
      setVolDown(true);
      showToast("Vol Down Trigger armed!");
    } else {
      setVolDown(false);
    }
  };

  // Simulate pressing Volume Key to activate Lumi Engine
  const handleSimulateVolumeTrigger = (keyName: "Vol Up" | "Vol Down") => {
    if (triggerBalance <= 0) {
      setShowRanOutModal(true);
      return;
    }

    const success = consumeTrigger();
    if (success) {
      setEngine(true);
      showToast(`⚡ ${keyName} pressed! Lumi Engine activated (-1 Trigger)`);
    } else {
      setShowRanOutModal(true);
    }
  };

  // Handle plus button click on Triggers card
  const handlePlusClick = () => {
    if (triggerBalance <= 0) {
      setShowRanOutModal(true);
    } else {
      setShowAdModal(true);
    }
  };

  // Start watching ad simulation
  const handleStartAd = () => {
    setIsWatchingAd(true);
    setAdCountdown(3);

    const interval = setInterval(() => {
      setAdCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsWatchingAd(false);
          addOneTrigger();
          setAdSuccessMessage(true);
          setTimeout(() => {
            setAdSuccessMessage(false);
            setShowAdModal(false);
            showToast("🎉 Trigger added successfully!");
          }, 1500);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  return (
    <PhoneShell
      header={
        <div className="flex items-center justify-between">
          <Link
            to="/how-it-works"
            className="flex size-10 items-center justify-center rounded-full bg-secondary text-ink"
            aria-label="How it works"
          >
            <HelpCircle className="size-5" />
          </Link>
          <span className="text-lg font-extrabold text-ink">Lumi</span>
          <button
            className="flex size-10 items-center justify-center rounded-full bg-secondary text-ink"
            aria-label="Notifications"
          >
            <Bell className="size-5" />
          </button>
        </div>
      }
    >
      <p className="text-sm text-muted-foreground">Hello,</p>
      <h1 className="text-3xl font-extrabold text-ink">{username || "Mark"}</h1>

      {/* Floating Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-20 left-1/2 z-50 -translate-x-1/2 rounded-full bg-ink/90 px-4 py-2 text-xs font-bold text-card shadow-lg backdrop-blur-md"
          >
            {toastMessage}
          </motion.div>
        )}
      </AnimatePresence>

      <section className="card-soft relative mt-5 p-6">
        <div className="flex items-start justify-between">
          <span className="inline-flex items-center gap-2 rounded-full bg-primary px-3 py-1 text-xs font-bold text-primary-foreground">
            <span className="size-1.5 rounded-full bg-primary-foreground animate-pulse" />
            LIVE
          </span>
          <LumiMascot className="h-16 w-16 filter drop-shadow-[0_4px_10px_rgba(0,0,0,0.15)] transition-transform hover:scale-110" />
        </div>
        <h2 className="mt-2 text-3xl leading-tight font-extrabold text-ink">
          Lumi Engine {engine ? "Active" : "Idle"}
        </h2>
        <div className="mt-3 flex items-end justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            Optimization protocols running at 98.4% efficiency.
          </p>
          <div className="flex shrink-0 flex-col items-center gap-1">
            <Switch checked={engine} onCheckedChange={setEngine} aria-label="Engine active" />
            <span className="text-[11px] font-medium text-muted-foreground">Engine Active</span>
          </div>
        </div>
      </section>

      {/* Triggers Section with Plus Button */}
      <section className="card-soft mt-4 px-6 py-5">
        <div className="flex items-center justify-between text-sm font-bold text-ink">
          <span className="flex items-center gap-2">
            <span
              className={`size-2.5 rounded-full ${
                triggerBalance > 0 ? "bg-primary animate-pulse" : "bg-red-500"
              }`}
            />
            Triggers
          </span>

          <div className="flex items-center gap-2.5">
            <span
              className={`text-sm font-extrabold ${
                triggerBalance === 0 ? "text-red-500" : "text-ink"
              }`}
            >
              {triggerBalance}/{maxTriggers}
            </span>
            <button
              onClick={handlePlusClick}
              className="glow-lime flex size-8 items-center justify-center rounded-full bg-primary text-primary-foreground font-black shadow-md transition-transform hover:scale-110 active:scale-90"
              aria-label="Add triggers"
              title="Add Triggers"
            >
              <Plus className="size-5 stroke-[3]" />
            </button>
          </div>
        </div>

        <div className="mt-3.5 h-3 overflow-hidden rounded-full bg-secondary relative">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              triggerBalance === 0 ? "bg-red-500" : "bg-primary"
            }`}
            style={{ width: `${(triggerBalance / maxTriggers) * 100}%` }}
          />
        </div>

        {triggerBalance === 0 && (
          <div className="mt-3 flex items-center justify-between rounded-xl bg-red-500/10 p-2.5 text-xs font-bold text-red-600">
            <span className="flex items-center gap-1.5">
              <AlertTriangle className="size-4 shrink-0" />
              Triggers ran out! Volume keys disabled.
            </span>
            <button
              onClick={() => setShowAdModal(true)}
              className="underline font-extrabold hover:opacity-80"
            >
              + Add
            </button>
          </div>
        )}
      </section>

      {/* Volume Trigger Cards */}
      <div className="mt-4 grid grid-cols-2 gap-4">
        <TriggerCard
          label="Vol Down"
          caption="Engine Output"
          checked={volDown && triggerBalance > 0}
          onChange={handleVolDownToggle}
          onSimulateKey={() => handleSimulateVolumeTrigger("Vol Down")}
          disabled={triggerBalance === 0}
          icon={<BarChart3 className="size-12 text-muted/80" />}
        />
        <TriggerCard
          label="Vol Up"
          caption="Performance Level"
          checked={volUp && triggerBalance > 0}
          onChange={handleVolUpToggle}
          onSimulateKey={() => handleSimulateVolumeTrigger("Vol Up")}
          disabled={triggerBalance === 0}
          icon={<Rocket className="size-12 text-muted/80" />}
        />
      </div>

      <section className="mt-8">
        <div className="relative overflow-hidden rounded-3xl">
          <img
            src={dailyMixTracks[0]?.cover || covers.mix}
            alt={`Daily mix cover art: ${dailyMixTracks[0]?.title || "Daily Mix"}`}
            width={1200}
            height={800}
            className="h-56 w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink/90 via-ink/20 to-transparent" />
          <div className="absolute inset-x-5 bottom-5 flex items-end justify-between gap-4">
            <div>
              <span className="rounded-full bg-primary px-3 py-1 text-xs font-extrabold tracking-wide text-primary-foreground">
                DAILY MIX
              </span>
              <h3 className="mt-3 text-2xl font-extrabold text-card">
                {dailyMixTracks[0]?.title || "Daily Mix"}
              </h3>
              <p className="text-sm font-semibold text-card/80">
                {dailyMixTracks[0]?.artist || "Lumi Selection"}
              </p>
            </div>
            <button
              onClick={() => {
                const featured = dailyMixTracks[0];
                if (!featured) return;
                if (currentTrack?.id === featured.id) {
                  togglePlayPause();
                } else {
                  playTrack(featured, dailyMixTracks);
                  setIsPlayerModalOpen(true);
                }
              }}
              className="glow-lime flex size-14 shrink-0 items-center justify-center rounded-full bg-primary hover:scale-110 transition-transform cursor-pointer"
              aria-label={
                isPlaying && currentTrack?.id === dailyMixTracks[0]?.id
                  ? "Pause daily mix"
                  : "Play daily mix"
              }
            >
              {isPlaying && currentTrack?.id === dailyMixTracks[0]?.id ? (
                <Pause className="size-6 fill-primary-foreground text-primary-foreground" />
              ) : (
                <Play className="size-6 fill-primary-foreground text-primary-foreground ml-0.5" />
              )}
            </button>
          </div>
        </div>
      </section>

      <section className="mt-8">
        <SectionTitle
          action={
            <Link to="/library" className="text-sm font-bold tracking-wide text-lime-deep">
              VIEW ALL
            </Link>
          }
        >
          Recently Played
        </SectionTitle>
        {recentlyPlayedHistory && recentlyPlayedHistory.length > 0 ? (
          <div className="no-scrollbar -mx-5 flex gap-4 overflow-x-auto px-5 pb-2">
            {recentlyPlayedHistory.map((t) => {
              const isCurrent = currentTrack?.id === t.id;
              const isThisPlaying = isCurrent && isPlaying;
              return (
                <div
                  key={t.id}
                  onClick={() => {
                    if (isCurrent) {
                      togglePlayPause();
                    } else {
                      playTrack(t, recentlyPlayedHistory);
                      setIsPlayerModalOpen(true);
                    }
                  }}
                  className="w-36 shrink-0 cursor-pointer group"
                >
                  <div className="relative aspect-square overflow-hidden rounded-3xl">
                    <img
                      src={t.cover || covers.midnightDrive}
                      alt={`${t.title} by ${t.artist}`}
                      loading="lazy"
                      width={600}
                      height={600}
                      className="size-full object-cover shadow-[var(--shadow-soft)] transition-transform group-hover:scale-105"
                    />
                    <div
                      className={`absolute inset-0 bg-black/40 flex items-center justify-center transition-opacity ${
                        isThisPlaying ? "opacity-100" : "opacity-0 group-hover:opacity-100"
                      }`}
                    >
                      <div className="size-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground shadow-md">
                        {isThisPlaying ? (
                          <Pause className="size-5 fill-current" />
                        ) : (
                          <Play className="size-5 fill-current ml-0.5" />
                        )}
                      </div>
                    </div>
                  </div>
                  <p className="mt-3 font-bold text-ink truncate">{t.title}</p>
                  <p className="text-sm text-muted-foreground truncate">{t.artist}</p>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="card-soft flex items-center justify-between p-4 text-sm text-muted-foreground">
            <span>No playback history yet. Start listening!</span>
            <Link to="/search" className="font-extrabold text-lime-deep underline">
              Find Tracks
            </Link>
          </div>
        )}
      </section>

      <section className="mt-8">
        <SectionTitle icon={<Zap className="size-6 fill-primary text-lime-deep" />}>
          Turbo Picks
        </SectionTitle>
        <ul className="space-y-3">
          {turboPicksTracks.map((t) => {
            const isCurrent = currentTrack?.id === t.id;
            const isThisPlaying = isCurrent && isPlaying;
            return (
              <li
                key={t.id}
                onClick={() => {
                  if (isCurrent) {
                    togglePlayPause();
                  } else {
                    playTrack(t, turboPicksTracks);
                    setIsPlayerModalOpen(true);
                  }
                }}
                className={`card-soft flex items-center gap-4 p-3 cursor-pointer transition-colors ${
                  isCurrent ? "border-primary bg-primary/5" : "hover:border-primary/50"
                }`}
              >
                <div className="relative size-14 shrink-0 overflow-hidden rounded-2xl">
                  <img
                    src={t.cover || covers.kinetic}
                    alt={`${t.title} by ${t.artist}`}
                    loading="lazy"
                    width={600}
                    height={600}
                    className="size-full object-cover"
                  />
                  <div
                    className={`absolute inset-0 bg-black/40 flex items-center justify-center transition-opacity ${
                      isThisPlaying ? "opacity-100" : "opacity-0 hover:opacity-100"
                    }`}
                  >
                    {isThisPlaying ? (
                      <Pause className="size-5 fill-white text-white" />
                    ) : (
                      <Play className="size-5 fill-white text-white ml-0.5" />
                    )}
                  </div>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-lg font-bold text-ink">{t.title}</p>
                  <p className="truncate text-sm text-muted-foreground">{t.artist}</p>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    startDownload(t);
                  }}
                  disabled={isDownloading(t.id)}
                  aria-label={`Download ${t.title}`}
                  className={`flex size-10 shrink-0 items-center justify-center rounded-full transition-all ${
                    isDownloaded(t.id)
                      ? "bg-secondary text-lime-deep"
                      : isDownloading(t.id)
                        ? "bg-secondary text-ink"
                        : "bg-secondary text-ink hover:bg-primary hover:text-primary-foreground hover:scale-105"
                  }`}
                >
                  {isDownloaded(t.id) ? (
                    <CheckCircle2 className="size-5 text-lime-deep" />
                  ) : isDownloading(t.id) ? (
                    <Loader2 className="size-5 animate-spin text-lime-deep" />
                  ) : (
                    <Download className="size-4" />
                  )}
                </button>
              </li>
            );
          })}
        </ul>
      </section>

      {/* POP-UP OVERLAY 1: Triggers Ran Out Notification */}
      <AnimatePresence>
        {showRanOutModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-sm rounded-3xl border border-border bg-card p-6 shadow-2xl text-center"
            >
              <button
                onClick={() => setShowRanOutModal(false)}
                className="absolute top-4 right-4 flex size-8 items-center justify-center rounded-full bg-secondary text-ink hover:opacity-80"
              >
                <X className="size-4" />
              </button>

              <div className="mx-auto flex size-16 items-center justify-center rounded-full bg-red-500/10 text-red-500">
                <AlertTriangle className="size-8" />
              </div>

              <h3 className="mt-4 text-2xl font-extrabold text-ink">Triggers Ran Out!</h3>

              <div className="mt-3 rounded-2xl bg-secondary/50 p-3 text-xs font-semibold text-muted-foreground">
                Current Balance:{" "}
                <span className="font-extrabold text-red-500">0 / {maxTriggers} Triggers</span>
              </div>

              <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                Your triggers have ran out! You cannot use the Volume Up or Volume Down buttons to
                activate Lumi engine until you add more triggers.
              </p>

              <div className="mt-6 space-y-2.5">
                <button
                  onClick={() => {
                    setShowRanOutModal(false);
                    setShowAdModal(true);
                  }}
                  className="glow-lime w-full flex items-center justify-center gap-2 rounded-2xl bg-primary py-3.5 text-base font-extrabold text-primary-foreground shadow-md transition-transform active:scale-95"
                >
                  <Plus className="size-5 stroke-[3]" />
                  Add Triggers
                </button>

                <button
                  onClick={() => setShowRanOutModal(false)}
                  className="w-full rounded-2xl bg-secondary py-3 text-sm font-bold text-ink hover:bg-secondary/80"
                >
                  Dismiss
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* POP-UP OVERLAY 2: Watch Ad to Add Triggers */}
      <AnimatePresence>
        {showAdModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-sm rounded-3xl border border-border bg-card p-6 shadow-2xl text-center"
            >
              <button
                onClick={() => {
                  if (!isWatchingAd) setShowAdModal(false);
                }}
                disabled={isWatchingAd}
                className="absolute top-4 right-4 flex size-8 items-center justify-center rounded-full bg-secondary text-ink hover:opacity-80 disabled:opacity-30"
              >
                <X className="size-4" />
              </button>

              <div className="mx-auto flex size-16 items-center justify-center rounded-full bg-primary/20 text-lime-deep">
                <Tv className="size-8" />
              </div>

              <h3 className="mt-4 text-2xl font-extrabold text-ink">Add Triggers</h3>

              <div className="mt-2 rounded-2xl bg-lime-500/10 p-3 text-xs font-bold text-lime-deep border border-lime-500/20">
                You are about to add triggers. Watch and add below in order to have a trigger.
              </div>

              {/* Simulated Ad Container */}
              <div className="mt-5 relative overflow-hidden rounded-2xl border border-border bg-ink p-4 text-card text-left">
                <div className="flex items-center justify-between text-[10px] font-extrabold uppercase tracking-widest text-primary">
                  <span className="flex items-center gap-1">
                    <Sparkles className="size-3 fill-primary" />
                    Lumi Boost Ad
                  </span>
                  <span>{isWatchingAd ? `${adCountdown}s` : "5 sec ad"}</span>
                </div>

                <div className="mt-3 flex items-center gap-3">
                  <LumiMascot className="size-12 shrink-0 animate-bounce" />
                  <div>
                    <p className="text-sm font-bold text-card">Lumi Engine Turbo Pack</p>
                    <p className="text-xs text-muted-foreground/80">
                      Watch this short ad to refill +1 trigger for your volume keys.
                    </p>
                  </div>
                </div>

                {/* Progress bar during watching */}
                {isWatchingAd && (
                  <div className="mt-4">
                    <div className="h-2 w-full overflow-hidden rounded-full bg-card/20">
                      <motion.div
                        className="h-full bg-primary"
                        initial={{ width: "0%" }}
                        animate={{ width: "100%" }}
                        transition={{ duration: 3, ease: "linear" }}
                      />
                    </div>
                    <p className="mt-2 text-center text-xs font-extrabold text-primary animate-pulse">
                      Watching ad... {adCountdown}s remaining
                    </p>
                  </div>
                )}
              </div>

              {adSuccessMessage ? (
                <div className="mt-6 flex items-center justify-center gap-2 rounded-2xl bg-primary p-4 text-base font-extrabold text-primary-foreground">
                  <CheckCircle2 className="size-6" />
                  +1 Trigger Added! ({triggerBalance}/{maxTriggers})
                </div>
              ) : (
                <div className="mt-6 space-y-2.5">
                  <button
                    onClick={handleStartAd}
                    disabled={isWatchingAd || triggerBalance >= maxTriggers}
                    className="glow-lime flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-3.5 text-base font-extrabold text-primary-foreground shadow-md transition-transform active:scale-95 disabled:opacity-50"
                  >
                    <Tv className="size-5" />
                    {triggerBalance >= maxTriggers
                      ? "Triggers Full (3/3)"
                      : isWatchingAd
                        ? "Watching Ad..."
                        : "Watch Ad & Add Trigger"}
                  </button>

                  <button
                    onClick={() => setShowAdModal(false)}
                    disabled={isWatchingAd}
                    className="w-full rounded-2xl bg-secondary py-3 text-sm font-bold text-ink hover:bg-secondary/80 disabled:opacity-40"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </PhoneShell>
  );
}

function TriggerCard({
  label,
  caption,
  checked,
  onChange,
  onSimulateKey,
  disabled,
  icon,
}: {
  label: string;
  caption: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  onSimulateKey: () => void;
  disabled?: boolean;
  icon: React.ReactNode;
}) {
  return (
    <div
      className={`card-soft relative overflow-hidden p-5 transition-all ${
        disabled ? "border-red-500/30 opacity-75" : ""
      }`}
    >
      <div className="pointer-events-none absolute -right-2 bottom-0 opacity-60">{icon}</div>

      {disabled && (
        <div className="absolute top-2 right-2 flex items-center gap-1 rounded-full bg-red-500/10 px-2 py-0.5 text-[10px] font-extrabold text-red-500">
          <Lock className="size-3" />
          No Triggers
        </div>
      )}

      <div className="relative flex flex-col items-center gap-2">
        <Switch checked={checked} onCheckedChange={onChange} aria-label={label} />
        <span className="flex items-center gap-1 text-sm font-bold text-ink">
          {checked ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />}
          {label}
        </span>
      </div>

      <p className="relative mt-3 text-center text-xs font-medium text-muted-foreground">
        {caption}
      </p>

      <button
        onClick={onSimulateKey}
        className={`mt-3 w-full rounded-xl py-2 text-xs font-black transition-transform active:scale-95 ${
          disabled
            ? "border border-red-500/20 bg-red-500/10 text-red-600"
            : "bg-secondary text-ink hover:bg-primary/20 hover:text-lime-deep"
        }`}
      >
        {disabled ? "Locked (0 Triggers)" : `Press ${label}`}
      </button>
    </div>
  );
}

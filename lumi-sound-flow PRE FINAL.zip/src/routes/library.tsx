import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  UserRound,
  Zap,
  RefreshCw,
  Library as LibraryIcon,
  Play,
  Pause,
  Trash2,
  CheckCircle2,
  FolderDown,
  HardDrive,
  ShieldCheck,
  Search,
  Check,
  ArrowRight,
} from "lucide-react";
import { PhoneShell, SectionTitle } from "@/components/lumi/PhoneShell";
import { useAudio } from "@/context/AudioContext";
import { useDownloads } from "@/context/DownloadContext";
import { TrackItem } from "@/lib/spotify";

export const Route = createFileRoute("/library")({
  head: () => ({
    meta: [
      { title: "Offline Download Center — My Library | Lumi" },
      {
        name: "description",
        content:
          "Track active Turbo Sync downloads, manage device storage, configure download folders, and play completed offline MP3 tracks.",
      },
      { property: "og:title", content: "Lumi Offline Download Center" },
      {
        property: "og:description",
        content: "Real device storage, active syncs, and authentic offline MP3 library.",
      },
    ],
  }),
  component: LibraryScreen,
});

function LibraryScreen() {
  const { currentTrack, isPlaying, playTrack, togglePlayPause, setIsPlayerModalOpen } = useAudio();
  const {
    downloadedTracks,
    activeSyncList,
    deleteDownloadedTrack,
    clearAllDownloads,
    storageInfo,
    requestStorageAccess,
    downloadFolder,
    pickDownloadFolder,
  } = useDownloads();

  const [permLoading, setPermLoading] = useState(false);
  const [permSuccess, setPermSuccess] = useState(storageInfo.isPersistent);

  const handleGrantPermission = async () => {
    setPermLoading(true);
    const granted = await requestStorageAccess();
    setPermLoading(false);
    setPermSuccess(granted);
  };

  const handlePlayTrack = (track: TrackItem) => {
    if (currentTrack?.id === track.id) {
      togglePlayPause();
    } else {
      playTrack(track, downloadedTracks);
      setIsPlayerModalOpen(true);
    }
  };

  return (
    <PhoneShell
      header={
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-2 text-2xl font-extrabold text-lime-deep">
            <UserRound className="size-6" />
            LUMI
          </span>
          <Zap className="size-6 fill-primary text-lime-deep" />
        </div>
      }
    >
      <div className="flex items-center justify-between">
        <h1 className="text-4xl font-extrabold text-ink">Downloads</h1>
        {downloadedTracks.length > 0 && (
          <button
            onClick={clearAllDownloads}
            className="text-xs font-extrabold text-muted-foreground hover:text-red-500 transition-colors"
          >
            Clear Offline Library
          </button>
        )}
      </div>

      {/* Real Device Storage Section */}
      <section className="card-soft mt-5 px-6 py-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <HardDrive className="size-5 text-lime-deep" />
            <p className="text-xl font-semibold text-ink">Device Storage</p>
          </div>
          <p className="text-sm font-bold text-ink">
            {storageInfo.usedGB} GB / {storageInfo.totalGB} GB used
          </p>
        </div>

        <div className="mt-3 h-3 overflow-hidden rounded-full bg-secondary">
          <div
            className="h-full rounded-full bg-primary transition-all duration-500"
            style={{ width: `${storageInfo.percent}%` }}
          />
        </div>

        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
          <span>
            {storageInfo.musicUsedMB} MB stored in {downloadedTracks.length} offline tracks
          </span>
          {permSuccess || storageInfo.isPersistent ? (
            <span className="inline-flex items-center gap-1 font-bold text-lime-deep">
              <ShieldCheck className="size-3.5" /> Storage Permission Granted
            </span>
          ) : (
            <button
              onClick={handleGrantPermission}
              disabled={permLoading}
              className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2.5 py-1 font-bold text-lime-deep hover:bg-primary/20 transition-colors"
            >
              {permLoading ? (
                "Requesting..."
              ) : (
                <>
                  <Check className="size-3" /> Grant Storage Permission
                </>
              )}
            </button>
          )}
        </div>
      </section>

      {/* Destination Download Folder Card */}
      <section className="card-soft mt-4 p-4 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-primary/15 text-lime-deep">
            <FolderDown className="size-6" />
          </div>
          <div className="min-w-0">
            <p className="text-xs font-extrabold uppercase tracking-wider text-muted-foreground">
              MP3 Download Destination
            </p>
            <p className="truncate text-base font-bold text-ink mt-0.5">{downloadFolder}</p>
          </div>
        </div>
        <button
          onClick={pickDownloadFolder}
          className="shrink-0 rounded-xl border border-border bg-background px-3 py-1.5 text-xs font-bold text-ink hover:border-primary/50 transition-colors"
        >
          Change Folder
        </button>
      </section>

      {/* Active Sync Section: ONLY shown when songs are downloading! */}
      {activeSyncList.length > 0 && (
        <section className="mt-8 animate-in fade-in duration-300">
          <div className="flex items-center justify-between mb-3">
            <SectionTitle icon={<RefreshCw className="size-6 text-lime-deep animate-spin" />}>
              Active Sync ({activeSyncList.length})
            </SectionTitle>
            <span className="text-xs font-bold text-lime-deep bg-primary/10 px-2.5 py-1 rounded-full">
              Downloading MP3s
            </span>
          </div>
          <ul className="space-y-4">
            {activeSyncList.map((d) => (
              <li key={d.id} className="card-soft p-4 border border-primary/40 shadow-lg">
                <div className="flex items-center gap-4">
                  <img
                    src={d.cover}
                    alt={`${d.title} by ${d.artist}`}
                    loading="lazy"
                    width={600}
                    height={600}
                    className="size-14 shrink-0 rounded-2xl object-cover border border-border"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-lg font-bold text-ink">{d.title}</p>
                    <p className="truncate text-sm text-muted-foreground">{d.artist}</p>
                    <p className="text-xs font-semibold text-lime-deep mt-0.5">{d.size}</p>
                  </div>
                  <div className="shrink-0 text-right">
                    <span className="rounded-full bg-ink px-3 py-1 text-xs font-extrabold text-primary">
                      {d.speed}
                    </span>
                    <p className="mt-1 text-xs font-bold text-ink">{d.progress}%</p>
                  </div>
                </div>
                <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-secondary">
                  <div
                    className="h-full rounded-full bg-primary transition-all duration-300"
                    style={{ width: `${d.progress}%` }}
                  />
                </div>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* Offline Library Section */}
      <section className="mt-8">
        <div className="flex items-center justify-between mb-3">
          <SectionTitle icon={<LibraryIcon className="size-6 text-lime-deep" />}>
            Offline Library ({downloadedTracks.length})
          </SectionTitle>
          <span className="text-xs font-bold text-muted-foreground">Local Device Storage</span>
        </div>

        {downloadedTracks.length === 0 ? (
          <div className="card-soft p-8 text-center rounded-3xl border border-dashed border-border mt-3">
            <LibraryIcon className="size-12 mx-auto text-muted-foreground/60 mb-3" />
            <p className="text-lg font-extrabold text-ink">No offline songs downloaded yet</p>
            <p className="text-sm text-muted-foreground mt-1 max-w-xs mx-auto">
              Download any song from Search or Home. Tracks are saved as 320kbps MP3s directly to
              your device for offline listening.
            </p>
            <Link
              to="/search"
              className="mt-5 inline-flex items-center gap-2 rounded-2xl bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground shadow-md hover:scale-105 transition-transform"
            >
              <Search className="size-4" /> Find & Download Songs <ArrowRight className="size-4" />
            </Link>
          </div>
        ) : (
          <ul className="space-y-3">
            {downloadedTracks.map((t) => {
              const isThisPlaying = currentTrack?.id === t.id && isPlaying;

              return (
                <li
                  key={t.id}
                  onClick={() => handlePlayTrack(t)}
                  className={`card-soft flex items-center gap-4 p-3.5 cursor-pointer hover:border-primary/50 transition-colors ${
                    isThisPlaying ? "border-primary/60 bg-primary/5" : ""
                  }`}
                >
                  <div className="relative size-14 shrink-0 group">
                    <img
                      src={t.cover}
                      alt={`${t.title} by ${t.artist}`}
                      loading="lazy"
                      width={600}
                      height={600}
                      className="size-14 rounded-2xl object-cover"
                    />
                    <div
                      className={`absolute inset-0 flex items-center justify-center rounded-2xl bg-black/40 text-white transition-opacity ${
                        isThisPlaying ? "opacity-100" : "opacity-0 group-hover:opacity-100"
                      }`}
                    >
                      {isThisPlaying ? (
                        <Pause className="size-5 fill-white" />
                      ) : (
                        <Play className="size-5 fill-white ml-0.5" />
                      )}
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <p className="truncate text-lg font-bold text-ink">{t.title}</p>
                      <CheckCircle2 className="size-4 text-lime-deep shrink-0" />
                    </div>
                    <p className="truncate text-sm text-muted-foreground">{t.artist}</p>
                    <p className="text-xs text-lime-deep font-semibold mt-0.5">
                      {t.quality || "320kbps MP3"} • {t.size}
                    </p>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handlePlayTrack(t);
                      }}
                      aria-label={`Play ${t.title}`}
                      className="flex size-11 shrink-0 items-center justify-center rounded-full bg-secondary text-ink hover:bg-primary hover:text-primary-foreground transition-colors"
                    >
                      {isThisPlaying ? (
                        <Pause className="size-5" />
                      ) : (
                        <Play className="size-5 ml-0.5" />
                      )}
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteDownloadedTrack(t.id);
                      }}
                      aria-label={`Remove ${t.title}`}
                      className="flex size-10 shrink-0 items-center justify-center rounded-full text-muted-foreground hover:text-red-500 hover:bg-red-500/10 transition-colors"
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </PhoneShell>
  );
}

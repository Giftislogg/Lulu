import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Search as SearchIcon,
  ArrowLeft,
  ArrowRight,
  Zap,
  HelpCircle,
  Headphones,
  Download,
  Gauge,
  Mic,
  Play,
  Pause,
  Loader2,
  Music,
  CheckCircle2,
  Radio,
} from "lucide-react";
import { PhoneShell, SectionTitle } from "@/components/lumi/PhoneShell";
import { TrackItem, searchSpotifyEngine } from "@/lib/spotify";
import { searchMusicFn, getChartFn } from "@/lib/server-functions";
import { useAudio } from "@/context/AudioContext";
import { useDownloads } from "@/context/DownloadContext";
import { calculateTrackMegabytes } from "@/lib/offlineStorage";

const categories = ["All Tracks", "Cyberpunk", "Synthwave", "Lo-Fi", "Techno", "Pop", "Rock"];
const filters = ["All", "Audio", "Stems", "Lossless", "Mixes"];

export const Route = createFileRoute("/search")({
  head: () => ({
    meta: [
      { title: "Turbo Search — Find & Stream Music | Lumi yt-dlp Engine" },
      {
        name: "description",
        content:
          "Search music via the Lumi yt-dlp engine, stream audio previews, and sync lossless audio in under a second.",
      },
      { property: "og:title", content: "Lumi Turbo Search (yt-dlp Engine)" },
      {
        property: "og:description",
        content: "Search music with high-speed yt-dlp engine integration and instant streaming.",
      },
    ],
  }),
  component: SearchScreen,
});

function SearchScreen() {
  const { currentTrack, isPlaying, playTrack, togglePlayPause } = useAudio();
  const { isDownloading, isDownloaded, startDownload } = useDownloads();

  const [query, setQuery] = useState("");
  const [category, setCategory] = useState(categories[0]);
  const [filter, setFilter] = useState(filters[0]);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<TrackItem[]>([]);
  const [trendingTracks, setTrendingTracks] = useState<TrackItem[]>([]);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const searching = query.trim().length > 0;

  const triggerToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  // Perform music search against Lumi music engine (with server & client fallback)
  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      setLoading(false);
      return;
    }

    setLoading(true);

    const timer = setTimeout(() => {
      searchMusicFn({ data: { query: query.trim(), limit: 20 } })
        .then((data) => {
          if (data && Array.isArray(data.tracks) && data.tracks.length > 0) {
            setResults(data.tracks);
            setLoading(false);
          } else {
            // Direct client search fallback
            searchSpotifyEngine(query.trim(), 20).then((res) => {
              setResults(res.tracks || []);
              setLoading(false);
            });
          }
        })
        .catch((err) => {
          console.error("Search fetch error, attempting direct search fallback:", err);
          searchSpotifyEngine(query.trim(), 20).then((res) => {
            setResults(res.tracks || []);
            setLoading(false);
          });
        });
    }, 250);

    return () => {
      clearTimeout(timer);
    };
  }, [query]);

  // Fetch initial trending / chart tracks on mount
  useEffect(() => {
    getChartFn({ data: { key: "top-50-global", limit: 8 } })
      .then((tracks) => {
        if (Array.isArray(tracks) && tracks.length > 0) {
          setTrendingTracks(tracks);
        } else {
          searchSpotifyEngine("Top Hits 2026", 6).then(
            (res) => res?.tracks && setTrendingTracks(res.tracks),
          );
        }
      })
      .catch(() => {
        searchSpotifyEngine("Top Hits 2026", 6).then(
          (res) => res?.tracks && setTrendingTracks(res.tracks),
        );
      });
  }, []);

  // Handle Play/Pause Audio
  const handleTogglePlay = (track: TrackItem) => {
    if (currentTrack?.id === track.id) {
      togglePlayPause();
    } else {
      playTrack(track, results);
    }
  };

  // Handle Real MP3 Download & Turbo Sync to Offline Library
  const handleDownload = async (track: TrackItem) => {
    if (isDownloading(track.id) || isDownloaded(track.id)) return;
    const meta = calculateTrackMegabytes(track);
    triggerToast(`Starting MP3 download for "${track.title}" (${meta.sizeStr})...`);
    await startDownload(track);
    triggerToast(`Downloaded "${track.title}" (${meta.sizeStr}) to Downloads folder!`);
  };

  const handleSelectCategory = (cat: string) => {
    setCategory(cat);
    if (cat === "All Tracks") {
      setQuery("Electronic");
    } else {
      setQuery(cat);
    }
  };

  return (
    <PhoneShell
      header={
        <div className="flex items-center justify-between">
          <Zap className="size-6 fill-primary text-lime-deep" />
          <span className="text-2xl font-extrabold text-lime-deep">Lumi</span>
          <Link to="/how-it-works" aria-label="How it works" className="text-ink">
            <HelpCircle className="size-6" />
          </Link>
        </div>
      }
    >
      {/* Floating Toast */}
      {toastMsg && (
        <div className="fixed top-20 left-1/2 z-50 -translate-x-1/2 rounded-full bg-ink/90 px-4 py-2 text-xs font-bold text-card shadow-lg backdrop-blur-md animate-in fade-in slide-in-from-top-2">
          {toastMsg}
        </div>
      )}

      {/* Search Input Box */}
      <div className="flex items-center gap-3">
        {searching ? (
          <button
            onClick={() => setQuery("")}
            aria-label="Clear search"
            className="flex size-12 shrink-0 items-center justify-center rounded-full bg-secondary text-ink hover:opacity-80 transition-opacity"
          >
            <ArrowLeft className="size-5" />
          </button>
        ) : null}
        <div className="flex flex-1 items-center gap-3 rounded-full bg-card px-5 py-3.5 shadow-[var(--shadow-soft)] border border-border/50">
          <SearchIcon className="size-5 text-lime-deep shrink-0" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search songs, artists, albums..."
            className="w-full bg-transparent text-base md:text-lg font-medium text-ink outline-none placeholder:text-muted-foreground"
            autoFocus
          />
          {loading ? (
            <Loader2 className="size-5 text-lime-deep animate-spin shrink-0" />
          ) : (
            <button
              onClick={() => {
                if (!query) setQuery("Daft Punk");
              }}
              aria-label="Search"
              className="text-lime-deep hover:scale-110 transition-transform"
            >
              <Mic className="size-5" />
            </button>
          )}
        </div>
      </div>

      {searching ? (
        <>
          <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground px-1">
            <span>
              {loading
                ? "Querying yt-dlp engine..."
                : `Found ${results.length} tracks for "${query}"`}
            </span>
            <span className="flex items-center gap-1 font-semibold text-lime-deep">
              <Radio className="size-3 animate-pulse" /> yt-dlp Engine Active
            </span>
          </div>

          <div className="no-scrollbar -mx-5 mt-4 flex gap-3 overflow-x-auto px-5">
            {filters.map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={
                  f === filter
                    ? "glow-lime shrink-0 rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground"
                    : "shrink-0 rounded-full bg-secondary px-5 py-2.5 text-sm font-medium text-muted-foreground"
                }
              >
                {f}
              </button>
            ))}
          </div>

          {loading ? (
            <div className="mt-12 flex flex-col items-center justify-center space-y-3 py-10">
              <Loader2 className="size-10 text-lime-deep animate-spin" />
              <p className="text-sm font-bold text-ink">Searching yt-dlp engine...</p>
              <p className="text-xs text-muted-foreground">
                Extracting high-resolution music metadata via yt-dlp
              </p>
            </div>
          ) : results.length === 0 ? (
            <div className="mt-12 text-center py-10 rounded-3xl bg-secondary/30 border border-border p-6">
              <Music className="size-12 mx-auto text-muted-foreground/60 mb-2" />
              <p className="text-lg font-extrabold text-ink">No tracks found</p>
              <p className="text-sm text-muted-foreground mt-1">
                Try searching for popular artists like "Daft Punk", "The Weeknd", or "Kavinsky"
              </p>
            </div>
          ) : (
            <ul className="mt-6 space-y-4">
              {results.map((r) => {
                const isThisTrackPlaying = currentTrack?.id === r.id && isPlaying;
                const isItemDownloading = isDownloading(r.id);
                const isItemDownloaded = isDownloaded(r.id);
                const meta = calculateTrackMegabytes(r);

                return (
                  <li
                    key={r.id}
                    onClick={() => handleTogglePlay(r)}
                    className={`card-soft flex items-center gap-4 p-3.5 transition-all cursor-pointer hover:border-primary/50 ${
                      isThisTrackPlaying ? "border-primary/60 bg-primary/5 shadow-md" : ""
                    }`}
                  >
                    {/* Cover Art with Play Button Overlay */}
                    <div className="relative size-16 shrink-0 group">
                      <img
                        src={r.cover}
                        alt={`${r.title} by ${r.artist}`}
                        loading="lazy"
                        className="size-16 rounded-2xl object-cover shadow-sm"
                      />
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleTogglePlay(r);
                        }}
                        className={`absolute inset-0 flex items-center justify-center rounded-2xl bg-black/40 text-white transition-opacity ${
                          isThisTrackPlaying ? "opacity-100" : "opacity-0 group-hover:opacity-100"
                        }`}
                        aria-label={`Play ${r.title}`}
                      >
                        {isThisTrackPlaying ? (
                          <Pause className="size-6 fill-white" />
                        ) : (
                          <Play className="size-6 fill-white ml-0.5" />
                        )}
                      </button>
                    </div>

                    {/* Track Info */}
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-base md:text-lg font-extrabold text-ink">
                        {r.title}
                      </p>
                      <p className="truncate text-sm text-muted-foreground">{r.artist}</p>
                      <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground flex-wrap">
                        <span className="rounded-md bg-secondary px-2 py-0.5 font-extrabold text-ink">
                          {r.quality || "320kbps MP3"}
                        </span>
                        <span>|</span>
                        <span>{r.duration}</span>
                        <span>|</span>
                        <span className="font-bold text-ink">{meta.sizeStr}</span>
                        <span className="flex items-center gap-1 font-bold text-lime-deep ml-auto">
                          <Zap className="size-3 fill-primary" />
                          {r.sync}
                        </span>
                      </div>
                    </div>

                    {/* Download / Sync Action */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDownload(r);
                      }}
                      disabled={isItemDownloading}
                      aria-label={`Download ${r.title}`}
                      className={`flex size-12 shrink-0 items-center justify-center rounded-full transition-all ${
                        isItemDownloaded
                          ? "bg-secondary text-lime-deep"
                          : isItemDownloading
                            ? "bg-secondary text-ink"
                            : "glow-lime bg-primary text-primary-foreground hover:scale-105"
                      }`}
                    >
                      {isItemDownloaded ? (
                        <CheckCircle2 className="size-6 text-lime-deep" />
                      ) : isItemDownloading ? (
                        <Loader2 className="size-6 animate-spin text-lime-deep" />
                      ) : (
                        <Download className="size-5" />
                      )}
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </>
      ) : (
        <>
          {/* Engine Categories */}
          <section className="mt-8">
            <h2 className="text-xl font-bold text-ink">Engine Categories</h2>
            <div className="no-scrollbar -mx-5 mt-4 flex gap-3 overflow-x-auto px-5">
              {categories.map((c) => (
                <button
                  key={c}
                  onClick={() => handleSelectCategory(c)}
                  className={
                    c === category
                      ? "glow-lime shrink-0 rounded-full bg-primary px-6 py-3 font-bold text-primary-foreground"
                      : "shrink-0 rounded-full bg-secondary px-6 py-3 font-semibold text-muted-foreground hover:text-ink transition-colors"
                  }
                >
                  {c}
                </button>
              ))}
            </div>
          </section>

          {/* Trending Now via SpotifyScraper Chart */}
          <section className="mt-8">
            <SectionTitle
              action={
                <button
                  onClick={() => setQuery("Top Hits")}
                  className="flex items-center gap-1 text-sm font-bold text-lime-deep hover:underline"
                >
                  View All <ArrowRight className="size-4" />
                </button>
              }
            >
              Trending Now
            </SectionTitle>
            <div className="no-scrollbar -mx-5 flex gap-4 overflow-x-auto px-5 pb-2">
              {trendingTracks.length > 0 ? (
                trendingTracks.map((t) => (
                  <article
                    key={t.id}
                    onClick={() => {
                      playTrack(t, trendingTracks);
                    }}
                    className="card-soft w-56 shrink-0 overflow-hidden rounded-3xl pb-4 cursor-pointer hover:border-primary/50 transition-all group"
                  >
                    <div className="relative">
                      <img
                        src={t.cover}
                        alt={t.title}
                        loading="lazy"
                        className="h-36 w-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <div className="size-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground shadow-lg">
                          <Play className="size-5 fill-current ml-0.5" />
                        </div>
                      </div>
                    </div>
                    <div className="px-4 pt-3">
                      <p className="text-base font-bold text-ink truncate">{t.title}</p>
                      <p className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground truncate">
                        <Headphones className="size-3.5 shrink-0" />
                        {t.artist}
                      </p>
                    </div>
                  </article>
                ))
              ) : (
                <div className="p-4 text-sm text-muted-foreground">Loading top charts...</div>
              )}
            </div>
          </section>

          {/* Global Throughput Metric Card */}
          <section className="card-soft mt-8 p-6">
            <div className="flex items-center justify-between gap-3">
              <h3 className="flex items-center gap-2 text-xl font-semibold text-ink">
                <Gauge className="size-6 text-lime-deep" />
                Global Throughput
              </h3>
              <span className="rounded-full bg-accent px-4 py-1.5 text-sm font-bold text-accent-foreground">
                Optimal
              </span>
            </div>
            <div className="mt-4 flex items-end justify-between">
              <p className="text-5xl font-extrabold text-ink">
                98.5 <span className="text-xl font-medium text-muted-foreground">MB/s</span>
              </p>
              <span className="flex items-center gap-2 text-lg text-ink">
                <span className="size-2.5 rounded-full bg-primary animate-ping" /> Live
              </span>
            </div>
            <div className="mt-5 h-3 overflow-hidden rounded-full bg-secondary">
              <div className="h-full w-[84%] rounded-full bg-primary" />
            </div>
          </section>
        </>
      )}
    </PhoneShell>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  Settings as SettingsIcon,
  Layers,
  Volume2,
  Mic,
  HardDrive,
  History,
  Sparkles,
  Zap,
  User,
} from "lucide-react";
import { PhoneShell, SectionTitle } from "@/components/lumi/PhoneShell";
import { Switch } from "@/components/ui/switch";
import { useMotionSettings } from "@/hooks/useMotionSettings";
import { useUser } from "@/hooks/useUser";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Engine Settings — Overlay, Triggers & Storage | Lumi" },
      {
        name: "description",
        content:
          "Control the Lumi floating overlay, volume-key shortcuts, voice listener, download quality and offline storage limits.",
      },
      { property: "og:title", content: "Lumi Engine Settings" },
      {
        property: "og:description",
        content: "Overlay mode, hardware triggers, voice search and storage management.",
      },
    ],
  }),
  component: SettingsScreen,
});

const groups = [
  {
    title: "Overlay Mode",
    icon: <Layers className="size-6 text-lime-deep" />,
    items: [
      {
        id: "overlay",
        label: "Floating orb over all apps",
        desc: "Draw Lumi on top of any app",
        on: true,
      },
      {
        id: "preview",
        label: "Quick preview in overlay",
        desc: "Stream 30s before downloading",
        on: true,
      },
      {
        id: "sticky",
        label: "Sticky mini controller",
        desc: "Keep transport controls docked",
        on: false,
      },
    ],
  },
  {
    title: "Hardware Triggers",
    icon: <Volume2 className="size-6 text-lime-deep" />,
    items: [
      { id: "volup", label: "Double Volume Up", desc: "Summons the floating orb", on: true },
      {
        id: "voldown",
        label: "Double Volume Down",
        desc: "Opens quick music controller",
        on: true,
      },
      { id: "hold", label: "Hold both keys", desc: "Starts the voice listener", on: false },
    ],
  },
  {
    title: "Voice & Discovery",
    icon: <Mic className="size-6 text-lime-deep" />,
    items: [
      { id: "listen", label: "Listen mode", desc: "Real-time speech to track match", on: true },
      { id: "auto", label: "Auto-play best match", desc: "Skip the results list", on: false },
    ],
  },
  {
    title: "Smart Management",
    icon: <Sparkles className="size-6 text-lime-deep" />,
    items: [
      {
        id: "history",
        label: "Track play history",
        desc: "Feeds Turbo Picks and Daily Mix",
        on: true,
      },
      {
        id: "playlists",
        label: "Auto-organize playlists",
        desc: "Group by mood, genre and BPM",
        on: true,
      },
      {
        id: "cleanup",
        label: "Storage auto-cleanup",
        desc: "Remove unplayed files after 30 days",
        on: false,
      },
    ],
  },
];

function SettingsScreen() {
  const { animationsEnabled, toggleAnimations } = useMotionSettings();
  const { username, setUsername } = useUser();
  const [state, setState] = useState<Record<string, boolean>>(() =>
    Object.fromEntries(groups.flatMap((g) => g.items.map((i) => [i.id, i.on]))),
  );

  return (
    <PhoneShell
      header={
        <div className="flex items-center justify-between">
          <span className="text-2xl font-extrabold text-lime-deep">Lumi</span>
          <SettingsIcon className="size-6 text-ink" />
        </div>
      }
    >
      <h1 className="text-4xl font-extrabold text-ink">Settings</h1>
      <p className="mt-2 text-base text-muted-foreground">
        Tune the engine, motion animations, overlay and offline storage.
      </p>

      {/* Profile Section */}
      <section className="mt-8">
        <SectionTitle icon={<User className="size-6 text-lime-deep" />}>Your Profile</SectionTitle>
        <div className="card-soft p-5">
          <label
            htmlFor="settings-username"
            className="block text-xs font-extrabold uppercase tracking-wider text-muted-foreground"
          >
            Display Name (Max 10 Characters)
          </label>
          <div className="relative mt-2 flex items-center">
            <input
              id="settings-username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              maxLength={10}
              placeholder="Your name"
              className="w-full rounded-2xl border border-border bg-background px-4 py-3 text-base font-bold text-ink placeholder:text-muted-foreground focus:border-primary focus:outline-none"
            />
            <span className="absolute right-3.5 text-xs font-bold text-muted-foreground">
              {username.length}/10
            </span>
          </div>
        </div>
      </section>

      {/* Interface & Motion Animations Section */}
      <section className="mt-8">
        <SectionTitle icon={<Zap className="size-6 text-lime-deep" />}>
          Interface & Motion
        </SectionTitle>
        <div className="card-soft flex items-center justify-between gap-4 p-5">
          <div className="min-w-0 flex-1">
            <p className="font-bold text-ink">Smooth Page & Touch Animations</p>
            <p className="text-sm text-muted-foreground">
              Smooth page scroll, tactile button press feedback and mascot eye blinking
            </p>
          </div>
          <Switch
            checked={animationsEnabled}
            onCheckedChange={toggleAnimations}
            aria-label="Toggle smooth app animations"
          />
        </div>
      </section>

      {groups.map((g) => (
        <section key={g.title} className="mt-8">
          <SectionTitle icon={g.icon}>{g.title}</SectionTitle>
          <ul className="space-y-3">
            {g.items.map((i) => (
              <li key={i.id} className="card-soft flex items-center gap-4 p-5">
                <div className="min-w-0 flex-1">
                  <p className="font-bold text-ink">{i.label}</p>
                  <p className="text-sm text-muted-foreground">{i.desc}</p>
                </div>
                <Switch
                  checked={state[i.id] ?? false}
                  onCheckedChange={(v) => setState((s) => ({ ...s, [i.id]: v }))}
                  aria-label={i.label}
                />
              </li>
            ))}
          </ul>
        </section>
      ))}

      <section className="mt-8">
        <SectionTitle icon={<HardDrive className="size-6 text-lime-deep" />}>Storage</SectionTitle>
        <div className="card-soft p-6">
          <div className="flex items-center justify-between text-sm font-bold text-ink">
            <span>Offline library</span>
            <span>1.2 GB / 5 GB</span>
          </div>
          <div className="mt-3 h-3 overflow-hidden rounded-full bg-secondary">
            <div className="h-full w-[24%] rounded-full bg-primary" />
          </div>
          <p className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
            <History className="size-4" />
            Last cleanup 4 days ago — 218 MB reclaimed
          </p>
        </div>
      </section>
    </PhoneShell>
  );
}

import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from "react";
import { TrackItem } from "@/lib/spotify";
import { synthAudioEngine } from "@/lib/audioSynthesizer";
import { getRealAudioPreviewUrl } from "@/lib/audioPreview";
import { ytAudioEngine, extractYouTubeVideoId } from "@/lib/youtubePlayer";
import { resolveYouTubeVideoIdFn } from "@/lib/server-functions";
import { getAudioBlob } from "@/lib/offlineStorage";

export type EqualizerPreset =
  "Normal" | "Bass Boost" | "Cyberpunk Synth" | "Vocal Clear" | "Spatial 3D";

interface AudioContextType {
  currentTrack: TrackItem | null;
  isPlaying: boolean;
  currentTime: number; // in seconds
  duration: number; // in seconds
  volume: number; // 0 to 1
  isMuted: boolean;
  eqPreset: EqualizerPreset;
  soundSourceMode: "audio_stream" | "unavailable" | "webaudio_synth" | "youtube_stream";
  isPlayerModalOpen: boolean;
  queue: TrackItem[];
  recentlyPlayedHistory: TrackItem[];
  playTrack: (track: TrackItem, newQueue?: TrackItem[]) => void;
  togglePlayPause: () => void;
  seek: (seconds: number) => void;
  setVolume: (vol: number) => void;
  toggleMute: () => void;
  setEqPreset: (preset: EqualizerPreset) => void;
  nextTrack: () => void;
  prevTrack: () => void;
  setIsPlayerModalOpen: (open: boolean) => void;
  getFrequencyData: () => Uint8Array;
}

const AudioContext = createContext<AudioContextType | null>(null);

export function AudioProvider({ children }: { children: React.ReactNode }) {
  const [currentTrack, setCurrentTrack] = useState<TrackItem | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(180);
  const [volume, setVolumeState] = useState<number>(0.85);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [eqPreset, setEqPreset] = useState<EqualizerPreset>("Cyberpunk Synth");
  const [soundSourceMode, setSoundSourceMode] = useState<
    "audio_stream" | "unavailable" | "webaudio_synth" | "youtube_stream"
  >("unavailable");
  const [isPlayerModalOpen, setIsPlayerModalOpen] = useState<boolean>(false);
  const [queue, setQueue] = useState<TrackItem[]>([]);
  const [recentlyPlayedHistory, setRecentlyPlayedHistory] = useState<TrackItem[]>([]);

  useEffect(() => {
    try {
      const saved = localStorage.getItem("lumi_recently_played");
      if (saved) {
        setRecentlyPlayedHistory(JSON.parse(saved));
      }
    } catch {
      // ignore
    }
  }, []);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const timerRef = useRef<number | null>(null);
  const ytSyncTimerRef = useRef<number | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);

  const currentTrackRef = useRef<TrackItem | null>(null);
  const queueRef = useRef<TrackItem[]>([]);

  useEffect(() => {
    currentTrackRef.current = currentTrack;
  }, [currentTrack]);

  useEffect(() => {
    queueRef.current = queue;
  }, [queue]);

  const nextTrack = useCallback(() => {
    const current = currentTrackRef.current;
    const q = queueRef.current;
    if (!current || q.length === 0) return;
    const currentIndex = q.findIndex((t) => t.id === current.id);
    const nextIndex = (currentIndex + 1) % q.length;
    playTrack(q[nextIndex]);
  }, []);

  const prevTrack = useCallback(() => {
    const current = currentTrackRef.current;
    const q = queueRef.current;
    if (!current || q.length === 0) return;
    const currentIndex = q.findIndex((t) => t.id === current.id);
    const prevIndex = (currentIndex - 1 + q.length) % q.length;
    playTrack(q[prevIndex]);
  }, []);

  // Initialize HTML5 Audio element for preview fallback
  useEffect(() => {
    audioRef.current = new Audio();
    audioRef.current.volume = volume;

    const audio = audioRef.current;

    const handleTimeUpdate = () => {
      if (audio && soundSourceMode === "audio_stream") {
        setCurrentTime(audio.currentTime);
        if (audio.duration && !isNaN(audio.duration)) {
          setDuration(audio.duration);
        }
      }
    };

    const handleEnded = () => {
      if (soundSourceMode === "audio_stream") {
        setIsPlaying(false);
        nextTrack();
      }
    };

    const handleError = () => {
      if (soundSourceMode === "audio_stream") {
        setSoundSourceMode("unavailable");
        setIsPlaying(false);
        synthAudioEngine.stopTrackSynth();
      }
    };

    audio.addEventListener("timeupdate", handleTimeUpdate);
    audio.addEventListener("ended", handleEnded);
    audio.addEventListener("error", handleError);

    return () => {
      audio.removeEventListener("timeupdate", handleTimeUpdate);
      audio.removeEventListener("ended", handleEnded);
      audio.removeEventListener("error", handleError);
      audio.pause();
    };
  }, [nextTrack, soundSourceMode, volume]);

  // Listen to YouTube Audio Engine state events
  useEffect(() => {
    const unsubState = ytAudioEngine.onStateChange((state) => {
      if (soundSourceMode !== "youtube_stream") return;

      // 1 = PLAYING
      if (state === 1) {
        setIsPlaying(true);
        const dur = ytAudioEngine.getDuration();
        if (dur > 0) setDuration(dur);
      }
      // 2 = PAUSED
      else if (state === 2) {
        setIsPlaying(false);
      }
      // 0 = ENDED
      else if (state === 0) {
        setIsPlaying(false);
        nextTrack();
      }
    });

    const unsubError = ytAudioEngine.onError((_code) => {
      console.warn("YouTube player encountered error, attempting fallback...");
      // Graceful fallback to preview audio if available
      const track = currentTrackRef.current;
      if (track && track.preview_url && audioRef.current) {
        setSoundSourceMode("audio_stream");
        audioRef.current.src = track.preview_url;
        audioRef.current
          .play()
          .then(() => setIsPlaying(true))
          .catch(() => setSoundSourceMode("unavailable"));
      } else {
        setSoundSourceMode("unavailable");
        setIsPlaying(false);
      }
    });

    return () => {
      unsubState();
      unsubError();
    };
  }, [nextTrack, soundSourceMode]);

  // Synchronize playback timeline when playing via YouTube engine
  useEffect(() => {
    if (isPlaying && soundSourceMode === "youtube_stream") {
      ytSyncTimerRef.current = window.setInterval(() => {
        const cur = ytAudioEngine.getCurrentTime();
        if (cur > 0) {
          setCurrentTime(cur);
        }
        const dur = ytAudioEngine.getDuration();
        if (dur > 0 && Math.abs(dur - duration) > 1) {
          setDuration(dur);
        }
      }, 500);
    } else {
      if (ytSyncTimerRef.current !== null) {
        clearInterval(ytSyncTimerRef.current);
        ytSyncTimerRef.current = null;
      }
    }

    return () => {
      if (ytSyncTimerRef.current !== null) {
        clearInterval(ytSyncTimerRef.current);
        ytSyncTimerRef.current = null;
      }
    };
  }, [isPlaying, soundSourceMode, duration]);

  // Timer loop for WebAudio Synth playback duration simulation
  useEffect(() => {
    if (isPlaying && soundSourceMode === "webaudio_synth") {
      timerRef.current = window.setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= duration) {
            nextTrack();
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    } else {
      if (timerRef.current !== null) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }

    return () => {
      if (timerRef.current !== null) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [isPlaying, soundSourceMode, duration, nextTrack]);

  const playTrack = async (track: TrackItem, newQueue?: TrackItem[]) => {
    setCurrentTrack(track);
    currentTrackRef.current = track;
    setCurrentTime(0);

    // Update Recently Played History
    setRecentlyPlayedHistory((prev) => {
      const filtered = prev.filter(
        (t) => t.id !== track.id && !(t.title === track.title && t.artist === track.artist),
      );
      const updated = [track, ...filtered].slice(0, 25);
      if (typeof window !== "undefined") {
        try {
          localStorage.setItem("lumi_recently_played", JSON.stringify(updated));
        } catch {
          // ignore
        }
      }
      return updated;
    });

    // Compute approximate duration in seconds from track format
    let trackDur = 180;
    if (track.duration_ms) {
      trackDur = Math.round(track.duration_ms / 1000);
    } else if (track.duration && track.duration.includes(":")) {
      const parts = track.duration.split(":");
      trackDur = parseInt(parts[0], 10) * 60 + parseInt(parts[1], 10);
    }
    setDuration(trackDur || 180);

    if (newQueue && newQueue.length > 0) {
      setQueue(newQueue);
      queueRef.current = newQueue;
    } else if (!queueRef.current.some((t) => t.id === track.id)) {
      const updated = [track, ...queueRef.current];
      setQueue(updated);
      queueRef.current = updated;
    }

    // Stop HTML5 audio and synth engines
    if (audioRef.current) {
      audioRef.current.pause();
    }
    synthAudioEngine.stopTrackSynth();

    // 0. Check if track is saved in offline IndexedDB storage for instant offline playing
    try {
      const offlineBlob = await getAudioBlob(track.id);
      if (offlineBlob && audioRef.current) {
        const objectUrl = URL.createObjectURL(offlineBlob);
        setSoundSourceMode("audio_stream");
        audioRef.current.src = objectUrl;
        audioRef.current.currentTime = 0;
        await audioRef.current.play();
        setIsPlaying(true);
        return;
      }
    } catch {
      // Continue to streaming engine
    }

    // 1. Check for immediate YouTube Video ID from yt-dlp
    const videoId = extractYouTubeVideoId(track);

    if (videoId) {
      setSoundSourceMode("youtube_stream");
      setIsPlaying(true);
      ytAudioEngine.setVolume(Math.round(volume * 100));
      await ytAudioEngine.playVideo(videoId);
      return;
    }

    // 2. If track doesn't have an ID yet, resolve in background via yt-dlp while checking preview
    const previewUrl = track.preview_url;
    if (!previewUrl) {
      getRealAudioPreviewUrl(track.title, track.artist).then((pUrl) => {
        if (
          pUrl &&
          currentTrackRef.current?.id === track.id &&
          soundSourceMode !== "youtube_stream"
        ) {
          track.preview_url = pUrl;
          if (audioRef.current) {
            audioRef.current.src = pUrl;
            audioRef.current
              .play()
              .then(() => setIsPlaying(true))
              .catch(() => {});
          }
        }
      });
    }

    // Attempt resolving YouTube ID for full song playback
    resolveYouTubeVideoIdFn({
      data: { title: track.title, artist: track.artist },
    })
      .then((resolvedId) => {
        if (resolvedId && currentTrackRef.current?.id === track.id) {
          track.raw_id = resolvedId;
          if (audioRef.current) {
            audioRef.current.pause();
          }
          setSoundSourceMode("youtube_stream");
          setIsPlaying(true);
          ytAudioEngine.setVolume(Math.round(volume * 100));
          ytAudioEngine.playVideo(resolvedId);
        }
      })
      .catch((err) => {
        console.warn("Could not resolve YouTube ID for track:", err);
      });

    // Meanwhile, if previewUrl is available, start it so user has instant audio
    if (previewUrl && audioRef.current) {
      setSoundSourceMode("audio_stream");
      audioRef.current.src = previewUrl;
      audioRef.current.currentTime = 0;
      audioRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch(() => {
          setSoundSourceMode("unavailable");
          setIsPlaying(false);
        });
    } else {
      setSoundSourceMode("unavailable");
      setIsPlaying(false);
    }
  };

  const togglePlayPause = () => {
    if (!currentTrack) return;

    if (soundSourceMode === "youtube_stream") {
      if (isPlaying) {
        setIsPlaying(false);
        ytAudioEngine.pause();
      } else {
        setIsPlaying(true);
        ytAudioEngine.play();
      }
      return;
    }

    if (soundSourceMode === "unavailable") {
      const vid = extractYouTubeVideoId(currentTrack);
      if (vid) {
        setSoundSourceMode("youtube_stream");
        setIsPlaying(true);
        ytAudioEngine.playVideo(vid);
        return;
      }

      if (currentTrack.preview_url && audioRef.current) {
        audioRef.current
          .play()
          .then(() => {
            setSoundSourceMode("audio_stream");
            setIsPlaying(true);
          })
          .catch(() => {
            setIsPlaying(false);
          });
      }
      return;
    }

    if (isPlaying) {
      setIsPlaying(false);
      if (soundSourceMode === "audio_stream" && audioRef.current) {
        audioRef.current.pause();
      } else {
        synthAudioEngine.stopTrackSynth();
      }
    } else {
      if (soundSourceMode === "audio_stream" && audioRef.current) {
        audioRef.current
          .play()
          .then(() => setIsPlaying(true))
          .catch(() => {
            setSoundSourceMode("unavailable");
            setIsPlaying(false);
          });
      } else if (soundSourceMode === "webaudio_synth") {
        setIsPlaying(true);
        synthAudioEngine.startTrackSynth(currentTrack.title, currentTrack.artist);
      }
    }
  };

  const seek = (seconds: number) => {
    setCurrentTime(seconds);
    if (soundSourceMode === "youtube_stream") {
      ytAudioEngine.seekTo(seconds, true);
    } else if (soundSourceMode === "audio_stream" && audioRef.current) {
      audioRef.current.currentTime = seconds;
    }
  };

  const setVolume = (vol: number) => {
    setVolumeState(vol);
    setIsMuted(vol === 0);
    if (audioRef.current) {
      audioRef.current.volume = vol;
    }
    ytAudioEngine.setVolume(Math.round(vol * 100));
    synthAudioEngine.setMasterVolume(vol);
  };

  const toggleMute = () => {
    if (isMuted) {
      setIsMuted(false);
      setVolume(volume || 0.8);
    } else {
      setIsMuted(true);
      if (audioRef.current) {
        audioRef.current.volume = 0;
      }
      ytAudioEngine.setVolume(0);
      synthAudioEngine.setMasterVolume(0);
    }
  };

  const getFrequencyData = (): Uint8Array => {
    const data = new Uint8Array(16);
    const analyser = synthAudioEngine.getAnalyser() || analyserRef.current;
    if (analyser && isPlaying) {
      analyser.getByteFrequencyData(data);
    } else if (isPlaying) {
      // Simulated live frequencies for visualizer
      for (let i = 0; i < 16; i++) {
        data[i] = Math.floor(80 + Math.random() * 150);
      }
    } else {
      data.fill(15);
    }
    return data;
  };

  return (
    <AudioContext.Provider
      value={{
        currentTrack,
        isPlaying,
        currentTime,
        duration,
        volume,
        isMuted,
        eqPreset,
        soundSourceMode,
        isPlayerModalOpen,
        queue,
        recentlyPlayedHistory,
        playTrack,
        togglePlayPause,
        seek,
        setVolume,
        toggleMute,
        setEqPreset,
        nextTrack,
        prevTrack,
        setIsPlayerModalOpen,
        getFrequencyData,
      }}
    >
      {children}
    </AudioContext.Provider>
  );
}

export function useAudio() {
  const ctx = useContext(AudioContext);
  if (!ctx) {
    throw new Error("useAudio must be used within an AudioProvider");
  }
  return ctx;
}

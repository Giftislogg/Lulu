/**
 * Lumi YouTube Audio Engine Bridge
 * Provides background full-length track streaming using the official YouTube IFrame Player API.
 * Keeps the clean native Lumi music player UI without displaying video clutter.
 */

interface YTPlayerInstance {
  loadVideoById: (options: { videoId: string; startSeconds?: number }) => void;
  playVideo: () => void;
  pauseVideo: () => void;
  stopVideo: () => void;
  seekTo: (seconds: number, allowSeekAhead?: boolean) => void;
  setVolume: (volume: number) => void;
  getCurrentTime: () => number;
  getDuration: () => number;
  getPlayerState: () => number;
}

interface YTNamespace {
  Player: new (
    elementId: string,
    options: {
      height?: string;
      width?: string;
      videoId?: string;
      playerVars?: Record<string, unknown>;
      events?: {
        onReady?: (event: { target: YTPlayerInstance }) => void;
        onStateChange?: (event: { data: number }) => void;
        onError?: (event: { data: number }) => void;
      };
    },
  ) => YTPlayerInstance;
}

declare global {
  interface Window {
    YT?: YTNamespace;
    onYouTubeIframeAPIReady?: () => void;
  }
}

export type YTPlayerStateChangeHandler = (state: number) => void;
export type YTPlayerErrorHandler = (error: number) => void;

class YouTubeAudioEngine {
  private player: YTPlayerInstance | null = null;
  private isApiReady: boolean = false;
  private isPlayerReady: boolean = false;
  private pendingVideoId: string | null = null;
  private pendingVolume: number = 85;
  private stateChangeListeners: Set<YTPlayerStateChangeHandler> = new Set();
  private errorListeners: Set<YTPlayerErrorHandler> = new Set();
  private containerId = "lumi-yt-audio-player-mount";
  private isInitializing = false;

  constructor() {
    if (typeof window !== "undefined") {
      this.initApi();
    }
  }

  public initApi(): Promise<void> {
    if (typeof window === "undefined") return Promise.resolve();
    if (this.isApiReady && this.player) return Promise.resolve();

    return new Promise((resolve) => {
      this.ensureContainer();

      if (window.YT && window.YT.Player) {
        this.isApiReady = true;
        this.mountPlayer().then(resolve);
        return;
      }

      const existingScript = document.getElementById("youtube-iframe-api");
      if (!existingScript) {
        const tag = document.createElement("script");
        tag.id = "youtube-iframe-api";
        tag.src = "https://www.youtube.com/iframe_api";
        const firstScriptTag = document.getElementsByTagName("script")[0];
        firstScriptTag?.parentNode?.insertBefore(tag, firstScriptTag);
      }

      const previousCallback = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => {
        if (previousCallback) previousCallback();
        this.isApiReady = true;
        this.mountPlayer().then(resolve);
      };
    });
  }

  private ensureContainer() {
    if (typeof document === "undefined") return;
    let container = document.getElementById(this.containerId);
    if (!container) {
      container = document.createElement("div");
      container.id = this.containerId;
      container.style.position = "fixed";
      container.style.bottom = "-200px";
      container.style.right = "-200px";
      container.style.width = "10px";
      container.style.height = "10px";
      container.style.opacity = "0.01";
      container.style.pointerEvents = "none";
      container.style.zIndex = "-9999";
      document.body.appendChild(container);
    }
  }

  private mountPlayer(): Promise<void> {
    if (this.isPlayerReady && this.player) return Promise.resolve();
    if (this.isInitializing) return Promise.resolve();
    this.isInitializing = true;

    this.ensureContainer();

    return new Promise((resolve) => {
      try {
        if (!window.YT || !window.YT.Player) {
          this.isInitializing = false;
          resolve();
          return;
        }

        this.player = new window.YT.Player(this.containerId, {
          height: "10",
          width: "10",
          videoId: "",
          playerVars: {
            autoplay: 1,
            controls: 0,
            disablekb: 1,
            fs: 0,
            playsinline: 1,
            rel: 0,
            enablejsapi: 1,
            origin: typeof window !== "undefined" ? window.location.origin : undefined,
          },
          events: {
            onReady: (event: { target: YTPlayerInstance }) => {
              this.isPlayerReady = true;
              this.isInitializing = false;
              if (this.pendingVolume !== undefined) {
                event.target.setVolume(this.pendingVolume);
              }
              if (this.pendingVideoId) {
                this.playVideo(this.pendingVideoId);
                this.pendingVideoId = null;
              }
              resolve();
            },
            onStateChange: (event: { data: number }) => {
              this.stateChangeListeners.forEach((fn) => fn(event.data));
            },
            onError: (event: { data: number }) => {
              console.warn("YouTube player audio warning/error code:", event.data);
              this.errorListeners.forEach((fn) => fn(event.data));
            },
          },
        });
      } catch (err) {
        console.warn("Error mounting YouTube audio iframe:", err);
        this.isInitializing = false;
        resolve();
      }
    });
  }

  public async playVideo(videoId: string): Promise<boolean> {
    await this.initApi();

    if (!this.player || !this.isPlayerReady) {
      this.pendingVideoId = videoId;
      return false;
    }

    try {
      if (typeof this.player.loadVideoById === "function") {
        this.player.loadVideoById({
          videoId: videoId,
          startSeconds: 0,
        });
        if (typeof this.player.playVideo === "function") {
          this.player.playVideo();
        }
        return true;
      }
    } catch (err) {
      console.warn("Failed to load video on YouTube player:", err);
    }
    return false;
  }

  public play() {
    if (this.player && typeof this.player.playVideo === "function") {
      this.player.playVideo();
    }
  }

  public pause() {
    if (this.player && typeof this.player.pauseVideo === "function") {
      this.player.pauseVideo();
    }
  }

  public stop() {
    if (this.player && typeof this.player.stopVideo === "function") {
      this.player.stopVideo();
    }
  }

  public seekTo(seconds: number, allowSeekAhead = true) {
    if (this.player && typeof this.player.seekTo === "function") {
      this.player.seekTo(seconds, allowSeekAhead);
    }
  }

  public setVolume(vol0to100: number) {
    this.pendingVolume = Math.max(0, Math.min(100, Math.round(vol0to100)));
    if (this.player && typeof this.player.setVolume === "function") {
      this.player.setVolume(this.pendingVolume);
    }
  }

  public getCurrentTime(): number {
    if (this.player && typeof this.player.getCurrentTime === "function") {
      return this.player.getCurrentTime() || 0;
    }
    return 0;
  }

  public getDuration(): number {
    if (this.player && typeof this.player.getDuration === "function") {
      return this.player.getDuration() || 0;
    }
    return 0;
  }

  public getPlayerState(): number {
    if (this.player && typeof this.player.getPlayerState === "function") {
      return this.player.getPlayerState();
    }
    return -1;
  }

  public onStateChange(callback: YTPlayerStateChangeHandler): () => void {
    this.stateChangeListeners.add(callback);
    return () => this.stateChangeListeners.delete(callback);
  }

  public onError(callback: YTPlayerErrorHandler): () => void {
    this.errorListeners.add(callback);
    return () => this.errorListeners.delete(callback);
  }
}

export const ytAudioEngine = new YouTubeAudioEngine();

/**
 * Extracts a YouTube 11-char video ID from track raw_id, id, url or uri
 */
export function extractYouTubeVideoId(track: {
  raw_id?: string;
  id?: string;
  url?: string;
  uri?: string;
}): string | null {
  if (track.raw_id && /^[a-zA-Z0-9_-]{11}$/.test(track.raw_id)) {
    return track.raw_id;
  }

  if (track.id) {
    if (track.id.startsWith("ytdlp_")) {
      const candidate = track.id.replace("ytdlp_", "");
      if (/^[a-zA-Z0-9_-]{11}$/.test(candidate)) return candidate;
    }
    if (/^[a-zA-Z0-9_-]{11}$/.test(track.id)) {
      return track.id;
    }
  }

  if (track.url) {
    const match = track.url.match(/(?:v=|\/|embed\/|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
    if (match && match[1]) {
      return match[1];
    }
  }

  if (track.uri && track.uri.startsWith("ytdlp:track:")) {
    const candidate = track.uri.replace("ytdlp:track:", "");
    if (/^[a-zA-Z0-9_-]{11}$/.test(candidate)) return candidate;
  }

  return null;
}

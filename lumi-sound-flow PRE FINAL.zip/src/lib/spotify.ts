export type TrackItem = {
  id: string;
  title: string;
  artist: string;
  artists: string[];
  cover: string;
  quality: string;
  size: string;
  sync: string;
  duration: string;
  duration_ms: number;
  preview_url: string | null;
  url: string;
  uri: string;
  explicit: boolean;
  engine?: string;
  uploader?: string;
  raw_id?: string;
};

export type SearchResultResponse = {
  query: string;
  tracks: TrackItem[];
  albums: Array<{ id: string; title: string; artist: string; cover: string; url: string }>;
  artists: Array<{ id: string; name: string; cover: string; url: string }>;
  total: number;
  engine?: string;
};

interface ItunesItem {
  trackId?: number;
  trackName?: string;
  trackCensoredName?: string;
  artistName?: string;
  artworkUrl100?: string;
  artworkUrl60?: string;
  trackTimeMillis?: number;
  previewUrl?: string;
  trackViewUrl?: string;
  trackExplicitness?: string;
}

// Safely invoke python bridge only on server side without polluting browser bundles
async function runPythonBridge(args: string[]): Promise<string | null> {
  if (typeof window !== "undefined") return null;
  // 1. Primary: Lumi yt-dlp engine bridge
  try {
    const cp = await import(/* @vite-ignore */ "child_process");
    const pathModule = await import(/* @vite-ignore */ "path");
    const utilModule = await import(/* @vite-ignore */ "util");

    const execFileAsync = utilModule.promisify(cp.execFile);
    const ytdlpBridgePath = pathModule.join(process.cwd(), "scripts", "ytdlp_bridge.py");
    const { stdout } = await execFileAsync("python3", [ytdlpBridgePath, ...args]);
    if (stdout && stdout.trim().startsWith("{")) {
      return stdout;
    }
  } catch (err) {
    console.warn("yt-dlp primary engine bridge execution note:", err);
  }

  // 2. Secondary fallback: SpotifyScraper if present
  try {
    const cp = await import(/* @vite-ignore */ "child_process");
    const pathModule = await import(/* @vite-ignore */ "path");
    const utilModule = await import(/* @vite-ignore */ "util");
    const execFileAsync = utilModule.promisify(cp.execFile);
    const fallbackPath = pathModule.join(
      process.cwd(),
      "SpotifyScraper-master",
      "scripts",
      "bridge.py",
    );
    const { stdout } = await execFileAsync("python3", [fallbackPath, ...args]);
    return stdout;
  } catch {
    return null;
  }
}

// Public iTunes Search API implementation
async function searchItunesApi(query: string, limit: number = 15): Promise<TrackItem[]> {
  try {
    const res = await fetch(
      `https://itunes.apple.com/search?term=${encodeURIComponent(query)}&media=music&entity=song&limit=${limit}`,
    );
    if (!res.ok) return [];
    const data = await res.json();
    if (!data.results || !Array.isArray(data.results)) return [];

    return data.results.map((item: ItunesItem) => {
      const durationMs = item.trackTimeMillis || 180000;
      const durationMin = Math.floor(durationMs / 60000);
      const durationSec = Math.floor((durationMs % 60000) / 1000);
      const durationStr = `${durationMin}:${durationSec < 10 ? "0" : ""}${durationSec}`;
      const sizeMb = Math.round(((((durationMs / 1000) * (320 / 8)) / 1024) * 10) / 10) || 7.2;

      let cover = item.artworkUrl100 || item.artworkUrl60 || "";
      if (cover) {
        cover = cover.replace("100x100bb", "600x600bb").replace("60x60bb", "600x600bb");
      }

      return {
        id: `itunes_${item.trackId || Math.random().toString(36).substring(2, 9)}`,
        title: item.trackName || item.trackCensoredName || "Untitled Track",
        artist: item.artistName || "Unknown Artist",
        artists: [item.artistName || "Unknown Artist"],
        cover:
          cover ||
          "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?auto=format&fit=crop&w=600&q=80",
        quality: "320kbps HQ",
        size: `${sizeMb}MB`,
        sync: "0.3s sync",
        duration: durationStr,
        duration_ms: durationMs,
        preview_url: item.previewUrl || null,
        url: item.trackViewUrl || "",
        uri: `itunes:track:${item.trackId}`,
        explicit: item.trackExplicitness === "explicit",
      };
    });
  } catch (err) {
    console.warn("iTunes API search failed:", err);
    return [];
  }
}

export async function searchSpotifyEngine(
  query: string,
  limit: number = 15,
): Promise<SearchResultResponse> {
  if (!query || !query.trim()) {
    return { query: "", tracks: [], albums: [], artists: [], total: 0, engine: "yt-dlp" };
  }

  const cleanQuery = query.trim();

  // Attempt yt-dlp primary engine bridge on server
  const pyOutput = await runPythonBridge(["search", cleanQuery, "--limit", limit.toString()]);
  if (pyOutput) {
    try {
      const data = JSON.parse(pyOutput);
      if (data && Array.isArray(data.tracks) && data.tracks.length > 0) {
        return data;
      }
    } catch {
      // ignore
    }
  }

  // Fallback / direct search via public music API
  const tracks = await searchItunesApi(cleanQuery, limit);

  // Generate album and artist cards from tracks
  const albums = tracks.slice(0, 4).map((t, idx) => ({
    id: `alb_${t.id}_${idx}`,
    title: `${t.title} (Album)`,
    artist: t.artist,
    cover: t.cover,
    url: t.url,
  }));

  const artists = Array.from(new Set(tracks.map((t) => t.artist)))
    .slice(0, 4)
    .map((artistName, idx) => {
      const matchingTrack = tracks.find((t) => t.artist === artistName);
      return {
        id: `art_${idx}`,
        name: artistName,
        cover:
          matchingTrack?.cover ||
          "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80",
        url: matchingTrack?.url || "",
      };
    });

  return {
    query: cleanQuery,
    tracks,
    albums,
    artists,
    total: tracks.length,
    engine: "yt-dlp",
  };
}

export const searchYtDlpEngine = searchSpotifyEngine;

export async function getChartSpotifyEngine(
  key: string = "top-50-global",
  limit: number = 10,
): Promise<TrackItem[]> {
  // Attempt yt-dlp python bridge on server
  const pyOutput = await runPythonBridge(["chart", "--key", key, "--limit", limit.toString()]);
  if (pyOutput) {
    try {
      const data = JSON.parse(pyOutput);
      if (data && Array.isArray(data.tracks) && data.tracks.length > 0) {
        return data.tracks;
      }
    } catch {
      // ignore
    }
  }

  // Fallback chart tracks via iTunes API
  return await searchItunesApi("Top Hits 2026", limit);
}

export const getChartYtDlpEngine = getChartSpotifyEngine;

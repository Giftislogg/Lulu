import { createServerFn } from "@tanstack/react-start";
import { searchSpotifyEngine, getChartSpotifyEngine, TrackItem } from "./spotify";
import { getRealAudioPreviewUrl } from "./audioPreview";

async function enrichTracksWithPreviews(tracks: TrackItem[]): Promise<TrackItem[]> {
  if (!tracks || tracks.length === 0) return [];
  return Promise.all(
    tracks.map(async (t) => {
      if (!t.preview_url) {
        const preview = await getRealAudioPreviewUrl(t.title, t.artist);
        if (preview) {
          t.preview_url = preview;
        }
      }
      return t;
    }),
  );
}

export const searchMusicFn = createServerFn({ method: "GET" })
  .validator((data: { query: string; limit?: number }) => data)
  .handler(async ({ data }) => {
    const res = await searchSpotifyEngine(data.query, data.limit || 15);
    if (res.tracks && res.tracks.length > 0) {
      res.tracks = await enrichTracksWithPreviews(res.tracks);
    }
    return res;
  });

export const getChartFn = createServerFn({ method: "GET" })
  .validator((data: { key?: string; limit?: number }) => data)
  .handler(async ({ data }) => {
    const tracks = await getChartSpotifyEngine(data.key || "top-50-global", data.limit || 10);
    return await enrichTracksWithPreviews(tracks);
  });

export const resolveYouTubeVideoIdFn = createServerFn({ method: "GET" })
  .validator((data: { title: string; artist: string }) => data)
  .handler(async ({ data }) => {
    const query = `${data.title} ${data.artist}`.trim();
    if (!query) return null;
    try {
      const res = await searchSpotifyEngine(query, 1);
      if (res.tracks && res.tracks.length > 0 && res.tracks[0].raw_id) {
        return res.tracks[0].raw_id;
      }
    } catch {
      // ignore
    }
    return null;
  });

function cleanString(str: string): string {
  if (!str) return "";
  return str
    .toLowerCase()
    .replace(/\(feat\.[^)]*\)/gi, "")
    .replace(/\[feat\.[^\]]*\]/gi, "")
    .replace(/\(ft\.[^)]*\)/gi, "")
    .replace(/\[ft\.[^\]]*\]/gi, "")
    .replace(/\([^)]*\)/g, "")
    .replace(/\[[^\]]*\]/g, "")
    .replace(/[^a-z0-9]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function verifyTrackMatch(
  targetTitle: string,
  targetArtist: string,
  candidateTitle: string,
  candidateArtist: string,
): boolean {
  const cleanTTitle = cleanString(targetTitle);
  const cleanTCandidateTitle = cleanString(candidateTitle);

  const cleanTArtist = cleanString(targetArtist);
  const cleanTCandidateArtist = cleanString(candidateArtist);

  if (!cleanTTitle || !cleanTCandidateTitle) return false;

  const titleExact = cleanTTitle === cleanTCandidateTitle;
  const titleContains =
    cleanTTitle.includes(cleanTCandidateTitle) || cleanTCandidateTitle.includes(cleanTTitle);

  if (!titleExact && !titleContains) {
    return false;
  }

  if (cleanTArtist && cleanTCandidateArtist) {
    const artistExact = cleanTArtist === cleanTCandidateArtist;
    const artistContains =
      cleanTArtist.includes(cleanTCandidateArtist) || cleanTCandidateArtist.includes(cleanTArtist);

    const targetArtistWords = cleanTArtist.split(" ").filter((w) => w.length > 2);
    const candidateArtistWords = cleanTCandidateArtist.split(" ").filter((w) => w.length > 2);
    const hasSharedArtistWord = targetArtistWords.some((w) => candidateArtistWords.includes(w));

    if (!artistExact && !artistContains && !hasSharedArtistWord) {
      return false;
    }
  }

  return true;
}

export async function getRealAudioPreviewUrl(
  title: string,
  artist: string,
): Promise<string | null> {
  const query = `${title} ${artist}`.trim();
  if (!query) return null;

  try {
    const res = await fetch(
      `https://itunes.apple.com/search?term=${encodeURIComponent(query)}&media=music&entity=song&limit=5`,
    );
    if (res.ok) {
      const data = await res.json();
      if (data.results && Array.isArray(data.results) && data.results.length > 0) {
        for (const candidate of data.results) {
          if (
            candidate.previewUrl &&
            verifyTrackMatch(title, artist, candidate.trackName || "", candidate.artistName || "")
          ) {
            return candidate.previewUrl as string;
          }
        }
        // Fallback to first result with previewUrl if strict verification fails
        const firstWithPreview = data.results.find((c: { previewUrl?: string }) => c.previewUrl);
        if (firstWithPreview) return firstWithPreview.previewUrl;
      }
    }
  } catch (err) {
    console.warn("iTunes preview fetch failed:", err);
  }

  try {
    const res = await fetch(`https://api.deezer.com/search?q=${encodeURIComponent(query)}&limit=5`);
    if (res.ok) {
      const data = await res.json();
      if (data.data && Array.isArray(data.data) && data.data.length > 0) {
        for (const candidate of data.data) {
          if (
            candidate.preview &&
            verifyTrackMatch(title, artist, candidate.title || "", candidate.artist?.name || "")
          ) {
            return candidate.preview as string;
          }
        }
        const firstWithPreview = data.data.find((c: { preview?: string }) => c.preview);
        if (firstWithPreview) return firstWithPreview.preview;
      }
    }
  } catch (err) {
    console.warn("Deezer preview fetch failed:", err);
  }

  return null;
}

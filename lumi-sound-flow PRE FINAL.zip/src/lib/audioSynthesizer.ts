/**
 * Web Audio Synthesizer Engine for Lumi Audio Output.
 * Generates rich, melodic, dynamic stereo audio output when
 * preview_url is absent or restricted by CORS/Spotify public API constraints.
 */

export class SynthAudioEngine {
  private ctx: AudioContext | null = null;
  private isRunning: boolean = false;
  private analyser: AnalyserNode | null = null;
  private timerId: number | null = null;
  private masterGain: GainNode | null = null;

  // Track info hash to generate unique key/tempo for each song
  private bpm: number = 118;
  private baseFreq: number = 220; // A3
  private scale: number[] = [0, 2, 4, 7, 9, 12, 14, 16]; // Major Pentatonic steps

  constructor() {
    // Lazy init on first user interaction
  }

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 64;

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.8, this.ctx.currentTime);

      this.masterGain.connect(this.analyser);
      this.analyser.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") {
      this.ctx.resume();
    }
  }

  public setMasterVolume(vol: number) {
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(Math.max(0, Math.min(1, vol)), this.ctx.currentTime);
    }
  }

  public getAnalyser(): AnalyserNode | null {
    return this.analyser;
  }

  public startTrackSynth(trackTitle: string, trackArtist: string) {
    this.initCtx();
    this.stopTrackSynth();

    if (!this.ctx || !this.masterGain) return;

    // Seed scale & tempo from track title
    let seed = 0;
    const str = (trackTitle + trackArtist).toLowerCase();
    for (let i = 0; i < str.length; i++) {
      seed += str.charCodeAt(i);
    }

    this.bpm = 100 + (seed % 35); // 100 to 135 bpm
    const keys = [220, 246.94, 261.63, 293.66, 329.63, 392.0]; // A, B, C, D, E, G
    this.baseFreq = keys[seed % keys.length];

    this.isRunning = true;
    const beatInterval = ((60 / this.bpm) * 1000) / 2; // 8th note interval

    let step = 0;

    const playStep = () => {
      if (!this.isRunning || !this.ctx || !this.masterGain) return;

      const now = this.ctx.currentTime;

      // Kick drum on quarter beats (steps 0, 4, 8, 12)
      if (step % 4 === 0) {
        const kickOsc = this.ctx.createOscillator();
        const kickGain = this.ctx.createGain();
        kickOsc.type = "sine";
        kickOsc.frequency.setValueAtTime(130, now);
        kickOsc.frequency.exponentialRampToValueAtTime(38, now + 0.12);

        kickGain.gain.setValueAtTime(0.9, now);
        kickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

        kickOsc.connect(kickGain);
        kickGain.connect(this.masterGain);

        kickOsc.start(now);
        kickOsc.stop(now + 0.16);
      }

      // Snare / clap on steps 4, 12
      if (step % 8 === 4) {
        const snareNoise = this.createNoiseBuffer();
        if (snareNoise) {
          const noiseSource = this.ctx.createBufferSource();
          noiseSource.buffer = snareNoise;

          const filter = this.ctx.createBiquadFilter();
          filter.type = "highpass";
          filter.frequency.value = 1000;

          const noiseGain = this.ctx.createGain();
          noiseGain.gain.setValueAtTime(0.35, now);
          noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

          noiseSource.connect(filter);
          filter.connect(noiseGain);
          noiseGain.connect(this.masterGain);

          noiseSource.start(now);
          noiseSource.stop(now + 0.2);
        }
      }

      // Hi-hat on every 8th note
      if (step % 2 === 0) {
        const hatOsc = this.ctx.createOscillator();
        const hatGain = this.ctx.createGain();
        const hatFilter = this.ctx.createBiquadFilter();

        hatOsc.type = "square";
        hatOsc.frequency.setValueAtTime(7000, now);

        hatFilter.type = "highpass";
        hatFilter.frequency.value = 6000;

        hatGain.gain.setValueAtTime(0.12, now);
        hatGain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

        hatOsc.connect(hatFilter);
        hatFilter.connect(hatGain);
        hatGain.connect(this.masterGain);

        hatOsc.start(now);
        hatOsc.stop(now + 0.06);
      }

      // Synth Arpeggio Melody
      const scaleDegree = this.scale[(step * 3 + seed) % this.scale.length];
      const freq = this.baseFreq * Math.pow(2, scaleDegree / 12);

      const synthOsc = this.ctx.createOscillator();
      const synthGain = this.ctx.createGain();
      const synthFilter = this.ctx.createBiquadFilter();

      synthOsc.type = step % 3 === 0 ? "sawtooth" : "triangle";
      synthOsc.frequency.setValueAtTime(freq, now);

      synthFilter.type = "lowpass";
      synthFilter.frequency.setValueAtTime(1200 + Math.sin(step * 0.2) * 600, now);
      synthFilter.Q.value = 4;

      synthGain.gain.setValueAtTime(0.22, now);
      synthGain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);

      synthOsc.connect(synthFilter);
      synthFilter.connect(synthGain);
      synthGain.connect(this.masterGain);

      synthOsc.start(now);
      synthOsc.stop(now + 0.25);

      step = (step + 1) % 16;
    };

    playStep();
    this.timerId = window.setInterval(playStep, beatInterval);
  }

  public stopTrackSynth() {
    this.isRunning = false;
    if (this.timerId !== null) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
  }

  private createNoiseBuffer(): AudioBuffer | null {
    if (!this.ctx) return null;
    const bufferSize = this.ctx.sampleRate * 0.2;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    return buffer;
  }
}

export const synthAudioEngine = new SynthAudioEngine();

import { useState, useEffect } from "react";

const USERNAME_KEY = "lumi_username";
const DEFAULT_USERNAME = "Mark";

export function useUser() {
  const [username, setUsernameState] = useState<string>(DEFAULT_USERNAME);

  useEffect(() => {
    const stored = localStorage.getItem(USERNAME_KEY);
    if (stored && stored.trim()) {
      setUsernameState(stored.trim().slice(0, 10));
    }
  }, []);

  const setUsername = (newName: string) => {
    const formatted = newName.slice(0, 10);
    setUsernameState(formatted);
    if (typeof window !== "undefined") {
      localStorage.setItem(USERNAME_KEY, formatted);
    }
  };

  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === USERNAME_KEY && e.newValue) {
        setUsernameState(e.newValue.slice(0, 10));
      }
    };
    window.addEventListener("storage", handleStorageChange);
    return () => window.removeEventListener("storage", handleStorageChange);
  }, []);

  return { username, setUsername };
}

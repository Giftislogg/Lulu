import { useState, useEffect } from "react";

const LOCAL_STORAGE_KEY = "lumi_motion_effects";

export function useMotionSettings() {
  const [animationsEnabled, setAnimationsEnabled] = useState<boolean>(true);

  useEffect(() => {
    const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (stored !== null) {
      setAnimationsEnabled(stored === "true");
    }
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    localStorage.setItem(LOCAL_STORAGE_KEY, String(animationsEnabled));
    if (animationsEnabled) {
      document.documentElement.classList.remove("disable-animations");
    } else {
      document.documentElement.classList.add("disable-animations");
    }
  }, [animationsEnabled]);

  const toggleAnimations = (enabled: boolean) => {
    setAnimationsEnabled(enabled);
  };

  return { animationsEnabled, toggleAnimations };
}

import { useState, useEffect } from "react";

const TRIGGERS_KEY = "lumi_available_triggers";
const DEFAULT_TRIGGERS = 3;
const MAX_TRIGGERS = 3;

export function useTriggers() {
  const [triggerBalance, setTriggerBalanceState] = useState<number>(DEFAULT_TRIGGERS);

  useEffect(() => {
    const stored = localStorage.getItem(TRIGGERS_KEY);
    if (stored !== null) {
      const parsed = parseInt(stored, 10);
      if (!isNaN(parsed)) {
        setTriggerBalanceState(Math.min(Math.max(parsed, 0), MAX_TRIGGERS));
      }
    }
  }, []);

  const setTriggerBalance = (count: number) => {
    const clamped = Math.min(Math.max(count, 0), MAX_TRIGGERS);
    setTriggerBalanceState(clamped);
    if (typeof window !== "undefined") {
      localStorage.setItem(TRIGGERS_KEY, String(clamped));
    }
  };

  const consumeTrigger = (): boolean => {
    if (triggerBalance > 0) {
      setTriggerBalance(triggerBalance - 1);
      return true;
    }
    return false;
  };

  const addOneTrigger = () => {
    setTriggerBalance(triggerBalance + 1);
  };

  const resetTriggers = () => {
    setTriggerBalance(MAX_TRIGGERS);
  };

  useEffect(() => {
    const handleStorage = (e: StorageEvent) => {
      if (e.key === TRIGGERS_KEY && e.newValue !== null) {
        const val = parseInt(e.newValue, 10);
        if (!isNaN(val)) {
          setTriggerBalanceState(Math.min(Math.max(val, 0), MAX_TRIGGERS));
        }
      }
    };
    window.addEventListener("storage", handleStorage);
    return () => window.removeEventListener("storage", handleStorage);
  }, []);

  return {
    triggerBalance,
    maxTriggers: MAX_TRIGGERS,
    consumeTrigger,
    addOneTrigger,
    resetTriggers,
    setTriggerBalance,
  };
}

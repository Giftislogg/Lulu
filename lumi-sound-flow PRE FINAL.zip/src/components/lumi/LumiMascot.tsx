import React, { useState } from "react";

interface LumiMascotProps {
  className?: string;
  imgClassName?: string;
  alt?: string;
}

export function LumiMascot({
  className = "relative inline-block",
  imgClassName = "h-full w-full object-contain",
  alt = "Lumi Mascot",
}: LumiMascotProps) {
  const [imgSrc, setImgSrc] = useState("/lumi_logo-removebg-preview.png");
  const [hasLoaded, setHasLoaded] = useState(false);

  return (
    <div className={`relative select-none pointer-events-none ${className}`}>
      {/* Base Mascot Image */}
      <img
        src={imgSrc}
        alt={alt}
        referrerPolicy="no-referrer"
        onLoad={() => setHasLoaded(true)}
        onError={() => {
          if (imgSrc !== "/lumi-mascot.jpg") {
            setImgSrc("/lumi-mascot.jpg");
          }
        }}
        className={imgClassName}
      />

      {/* SVG Definitions for Skin Gradient */}
      <svg className="absolute size-0 overflow-hidden" aria-hidden="true">
        <defs>
          <linearGradient id="lumi-skin-gradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#b4dc58" />
            <stop offset="50%" stopColor="#a0c843" />
            <stop offset="100%" stopColor="#8db532" />
          </linearGradient>
        </defs>
      </svg>

      {/* Eye blink overlays only appear when base mascot character is loaded */}
      {hasLoaded && (
        <>
          {/* Left Eye Blink Overlay */}
          <div
            className="animate-eye-blink absolute z-10 pointer-events-none"
            style={{
              top: "43%",
              left: "39.5%",
              width: "10.5%",
              height: "11%",
            }}
          >
            <svg viewBox="0 0 24 24" className="h-full w-full overflow-visible">
              {/* Cover White Eye Sclera with Lumi's Skin Tone */}
              <ellipse cx="12" cy="12" rx="11" ry="11" fill="url(#lumi-skin-gradient)" />
              {/* Eyelash / Closed Eye Arc */}
              <path
                d="M 2.5 12 C 7 18.5, 17 18.5, 21.5 12"
                fill="none"
                stroke="#21310a"
                strokeWidth="2.5"
                strokeLinecap="round"
              />
            </svg>
          </div>

          {/* Right Eye Blink Overlay */}
          <div
            className="animate-eye-blink absolute z-10 pointer-events-none"
            style={{
              top: "43.8%",
              left: "50.8%",
              width: "10.5%",
              height: "11%",
            }}
          >
            <svg viewBox="0 0 24 24" className="h-full w-full overflow-visible">
              {/* Cover White Eye Sclera with Lumi's Skin Tone */}
              <ellipse cx="12" cy="12" rx="11" ry="11" fill="url(#lumi-skin-gradient)" />
              {/* Eyelash / Closed Eye Arc */}
              <path
                d="M 2.5 12 C 7 18.5, 17 18.5, 21.5 12"
                fill="none"
                stroke="#21310a"
                strokeWidth="2.5"
                strokeLinecap="round"
              />
            </svg>
          </div>
        </>
      )}
    </div>
  );
}

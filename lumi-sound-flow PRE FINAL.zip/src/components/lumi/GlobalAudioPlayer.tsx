import { useState, useEffect } from "react";
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  ChevronDown,
  Zap,
  Sliders,
  Shuffle,
  Repeat,
  Radio,
  RadioTower,
  Download,
  Loader2,
  CheckCircle2,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useAudio, EqualizerPreset } from "@/context/AudioContext";
import { useDownloads } from "@/context/DownloadContext";

export function GlobalAudioPlayer() {
  const {
    currentTrack,
    isPlaying,
    currentTime,
    duration,
    volume,
    isMuted,
    eqPreset,
    soundSourceMode,
    isPlayerModalOpen,
    togglePlayPause,
    seek,
    setVolume,
    toggleMute,
    setEqPreset,
    nextTrack,
    prevTrack,
    setIsPlayerModalOpen,
    getFrequencyData,
  } = useAudio();
  const { isDownloading, isDownloaded, startDownload } = useDownloads();

  const [freqBars, setFreqBars] = useState<number[]>(new Array(16).fill(20));
  const [isShuffle, setIsShuffle] = useState(false);
  const [isRepeat, setIsRepeat] = useState(false);

  // Animate audio visualizer bars
  useEffect(() => {
    let animId: number;

    const updateBars = () => {
      if (isPlaying) {
        const data = getFrequencyData();
        const bars = Array.from(data)
          .slice(0, 16)
          .map((val) => Math.max(12, val));
        setFreqBars(bars);
      } else {
        setFreqBars(new Array(16).fill(10));
      }
      animId = requestAnimationFrame(updateBars);
    };

    animId = requestAnimationFrame(updateBars);
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, getFrequencyData]);

  if (!currentTrack) return null;

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = Math.floor(secs % 60);
    return `${mins}:${rem < 10 ? "0" : ""}${rem}`;
  };

  const eqPresetsList: EqualizerPreset[] = [
    "Normal",
    "Bass Boost",
    "Cyberpunk Synth",
    "Vocal Clear",
    "Spatial 3D",
  ];

  return (
    <>
      {/* 1. Persistent Mini Audio Player Bar above BottomNav */}
      <div className="fixed inset-x-0 bottom-20 z-30 mx-auto w-full max-w-md px-3 pointer-events-auto">
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          onClick={() => setIsPlayerModalOpen(true)}
          className="flex items-center justify-between gap-3 rounded-2xl border border-primary/30 bg-card/95 p-2.5 shadow-2xl backdrop-blur-lg cursor-pointer hover:border-primary/60 transition-all"
        >
          {/* Cover & Title */}
          <div className="flex items-center gap-3 min-w-0 flex-1">
            <div className="relative size-11 shrink-0 overflow-hidden rounded-xl">
              <img
                src={currentTrack.cover}
                alt={currentTrack.title}
                className="size-full object-cover"
              />
              {isPlaying && (
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center gap-0.5">
                  <span className="w-1 h-3 bg-primary animate-pulse rounded-full" />
                  <span className="w-1 h-4 bg-primary animate-pulse delay-75 rounded-full" />
                  <span className="w-1 h-2 bg-primary animate-pulse delay-150 rounded-full" />
                </div>
              )}
            </div>

            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-extrabold text-ink">{currentTrack.title}</p>
              <div className="flex items-center gap-1.5 min-w-0">
                <p className="truncate text-xs text-muted-foreground">{currentTrack.artist}</p>
                {soundSourceMode === "youtube_stream" ? (
                  <span className="shrink-0 rounded-md bg-lime-500/15 px-1.5 py-0.5 text-[10px] font-bold text-lime-600 dark:text-lime-400">
                    Full Track
                  </span>
                ) : soundSourceMode === "unavailable" ? (
                  <span className="shrink-0 rounded-md bg-amber-500/15 px-1.5 py-0.5 text-[10px] font-bold text-amber-600 dark:text-amber-400">
                    Preview Unavailable
                  </span>
                ) : null}
              </div>
            </div>
          </div>

          {/* Mini Equalizer Wave */}
          <div className="hidden sm:flex items-end gap-0.5 h-5 px-2">
            {freqBars.slice(0, 6).map((val, idx) => (
              <div
                key={idx}
                className="w-1 rounded-full bg-primary transition-all duration-75"
                style={{ height: `${Math.min(100, (val / 255) * 100)}%` }}
              />
            ))}
          </div>

          {/* Controls */}
          <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
            <button
              onClick={togglePlayPause}
              className="flex size-10 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-md hover:scale-105 transition-transform"
              aria-label={isPlaying ? "Pause" : "Play"}
            >
              {isPlaying ? (
                <Pause className="size-5 fill-current" />
              ) : (
                <Play className="size-5 fill-current ml-0.5" />
              )}
            </button>

            <button
              onClick={nextTrack}
              className="flex size-9 items-center justify-center rounded-full bg-secondary text-ink hover:bg-secondary/80 transition-colors"
              aria-label="Next track"
            >
              <SkipForward className="size-4" />
            </button>
          </div>
        </motion.div>
      </div>

      {/* 2. Full-Screen Audio Output Player Modal */}
      <AnimatePresence>
        {isPlayerModalOpen && (
          <motion.div
            initial={{ opacity: 0, y: "100%" }}
            animate={{ opacity: 1, y: "0%" }}
            exit={{ opacity: 0, y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-50 flex flex-col bg-background p-6 overflow-y-auto"
          >
            {/* Header */}
            <div className="flex items-center justify-between">
              <button
                onClick={() => setIsPlayerModalOpen(false)}
                className="flex size-10 items-center justify-center rounded-full bg-secondary text-ink hover:opacity-80 transition-opacity"
                aria-label="Close player"
              >
                <ChevronDown className="size-6" />
              </button>
              <div className="text-center">
                <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
                  Playing Audio Output
                </p>
                <span
                  className={`flex items-center justify-center gap-1 text-xs font-bold ${
                    soundSourceMode === "unavailable" ? "text-amber-500" : "text-lime-deep"
                  }`}
                >
                  <RadioTower className="size-3.5 animate-pulse" />
                  {soundSourceMode === "youtube_stream"
                    ? "Full Song • YouTube Engine"
                    : soundSourceMode === "audio_stream"
                      ? "Verified Audio Stream"
                      : soundSourceMode === "unavailable"
                        ? "Preview Unavailable"
                        : "WebAudio Synth Engine"}
                </span>
              </div>
              <button
                onClick={() => setIsPlayerModalOpen(false)}
                className="flex size-10 items-center justify-center rounded-full bg-secondary text-ink"
                aria-label="Equalizer"
              >
                <Sliders className="size-5" />
              </button>
            </div>

            {/* Album Artwork with Aura Glow */}
            <div className="relative my-8 mx-auto w-full max-w-xs aspect-square">
              <div
                className={`absolute inset-0 rounded-3xl bg-primary/20 blur-2xl transition-opacity ${
                  isPlaying ? "opacity-100 scale-105" : "opacity-30"
                }`}
              />
              <img
                src={currentTrack.cover}
                alt={currentTrack.title}
                className="relative z-10 size-full rounded-3xl object-cover shadow-2xl border border-border/50"
              />
            </div>

            {/* Track Info */}
            <div className="text-center px-4">
              <h2 className="text-2xl md:text-3xl font-extrabold text-ink truncate">
                {currentTrack.title}
              </h2>
              <p className="mt-1 text-base font-semibold text-muted-foreground">
                {currentTrack.artist}
              </p>

              {/* Quick Download MP3 Button */}
              <div className="mt-3 flex items-center justify-center gap-2">
                <button
                  onClick={() => startDownload(currentTrack)}
                  disabled={isDownloading(currentTrack.id)}
                  className="inline-flex items-center gap-1.5 rounded-full bg-secondary px-4 py-1.5 text-xs font-bold text-ink hover:border-primary/50 border border-border transition-colors cursor-pointer"
                >
                  {isDownloaded(currentTrack.id) ? (
                    <>
                      <CheckCircle2 className="size-3.5 text-lime-deep" /> In Offline Library (
                      {currentTrack.size || "8.5MB"})
                    </>
                  ) : isDownloading(currentTrack.id) ? (
                    <>
                      <Loader2 className="size-3.5 animate-spin text-lime-deep" /> Downloading
                      MP3...
                    </>
                  ) : (
                    <>
                      <Download className="size-3.5 text-primary" /> Download MP3 (
                      {currentTrack.size || "8.5MB"})
                    </>
                  )}
                </button>
              </div>

              {soundSourceMode === "unavailable" && (
                <div className="mt-3 inline-block rounded-xl bg-amber-500/10 border border-amber-500/20 px-4 py-2 text-center">
                  <p className="text-xs font-bold text-amber-600 dark:text-amber-400">
                    Preview Unavailable
                  </p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">
                    No verified audio clip matches this exact track.
                  </p>
                </div>
              )}
            </div>

            {/* 16-Bar Spectrum Audio Visualizer */}
            <div className="my-6 flex items-end justify-center gap-1.5 h-16 px-6">
              {freqBars.map((val, i) => (
                <div
                  key={i}
                  className="w-2 rounded-t-full bg-primary transition-all duration-75"
                  style={{
                    height: `${Math.max(10, Math.min(100, (val / 255) * 100))}%`,
                    opacity: isPlaying ? 0.9 : 0.3,
                  }}
                />
              ))}
            </div>

            {/* Scrubber / Progress Slider */}
            <div className="px-2">
              <input
                type="range"
                min={0}
                max={duration || 100}
                value={currentTime}
                onChange={(e) => seek(parseFloat(e.target.value))}
                className="w-full accent-primary h-2 rounded-lg cursor-pointer bg-secondary"
              />
              <div className="mt-2 flex justify-between text-xs font-bold text-muted-foreground">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            {/* Main Playback Controls */}
            <div className="mt-6 flex items-center justify-around px-4">
              <button
                onClick={() => setIsShuffle(!isShuffle)}
                className={`p-2 transition-colors ${isShuffle ? "text-lime-deep font-bold" : "text-muted-foreground"}`}
                aria-label="Shuffle"
              >
                <Shuffle className="size-5" />
              </button>

              <button
                onClick={prevTrack}
                className="flex size-12 items-center justify-center rounded-full bg-secondary text-ink hover:scale-105 transition-transform"
                aria-label="Previous track"
              >
                <SkipBack className="size-6 fill-current" />
              </button>

              <button
                onClick={togglePlayPause}
                className="glow-lime flex size-18 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-xl hover:scale-110 transition-transform"
                aria-label={isPlaying ? "Pause" : "Play"}
              >
                {isPlaying ? (
                  <Pause className="size-8 fill-current" />
                ) : (
                  <Play className="size-8 fill-current ml-1" />
                )}
              </button>

              <button
                onClick={nextTrack}
                className="flex size-12 items-center justify-center rounded-full bg-secondary text-ink hover:scale-105 transition-transform"
                aria-label="Next track"
              >
                <SkipForward className="size-6 fill-current" />
              </button>

              <button
                onClick={() => setIsRepeat(!isRepeat)}
                className={`p-2 transition-colors ${isRepeat ? "text-lime-deep font-bold" : "text-muted-foreground"}`}
                aria-label="Repeat"
              >
                <Repeat className="size-5" />
              </button>
            </div>

            {/* EQ Presets Selector */}
            <div className="mt-8">
              <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3 px-1">
                Equalizer Audio Profile
              </p>
              <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
                {eqPresetsList.map((preset) => (
                  <button
                    key={preset}
                    onClick={() => setEqPreset(preset)}
                    className={
                      eqPreset === preset
                        ? "rounded-full bg-primary px-4 py-2 text-xs font-bold text-primary-foreground shadow-sm"
                        : "rounded-full bg-secondary px-4 py-2 text-xs font-semibold text-muted-foreground hover:text-ink"
                    }
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            {/* Volume Controls */}
            <div className="mt-6 flex items-center gap-3 px-2">
              <button onClick={toggleMute} aria-label={isMuted ? "Unmute" : "Mute"}>
                {isMuted ? (
                  <VolumeX className="size-5 text-muted-foreground" />
                ) : (
                  <Volume2 className="size-5 text-lime-deep" />
                )}
              </button>
              <input
                type="range"
                min={0}
                max={1}
                step={0.01}
                value={isMuted ? 0 : volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="w-full accent-primary h-2 rounded-lg cursor-pointer bg-secondary"
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

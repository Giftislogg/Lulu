import { Link, useRouterState } from "@tanstack/react-router";
import { Home, Search, Library, Settings } from "lucide-react";

const items = [
  { to: "/home", label: "Home", icon: Home },
  { to: "/search", label: "Search", icon: Search },
  { to: "/library", label: "Library", icon: Library },
  { to: "/settings", label: "Settings", icon: Settings },
] as const;

export function BottomNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 mx-auto flex w-full max-w-md items-center justify-around rounded-t-4xl border-t border-border bg-card/95 px-4 pt-3 pb-5 backdrop-blur">
      {items.map(({ to, label, icon: Icon }) => {
        const active = pathname === to;
        return (
          <Link
            key={to}
            to={to}
            className={
              active
                ? "glow-lime flex min-w-20 flex-col items-center gap-1 rounded-full bg-primary px-5 py-2.5 text-primary-foreground"
                : "flex min-w-20 flex-col items-center gap-1 rounded-full px-5 py-2.5 text-muted-foreground transition-colors hover:text-foreground"
            }
          >
            <Icon className="size-5" strokeWidth={2} />
            <span className="text-[11px] font-semibold">{label}</span>
          </Link>
        );
      })}
    </nav>
  );
}

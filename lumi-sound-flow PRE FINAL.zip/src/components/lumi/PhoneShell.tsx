import type { ReactNode } from "react";
import { motion } from "motion/react";
import { BottomNav } from "./BottomNav";

export function PhoneShell({
  header,
  children,
  nav = true,
}: {
  header?: ReactNode;
  children: ReactNode;
  nav?: boolean;
}) {
  return (
    <div className="min-h-screen bg-background">
      <div className="relative mx-auto flex min-h-screen w-full max-w-md flex-col">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-72 ambient-glow" />
        {header ? (
          <header className="sticky top-0 z-30 border-b border-border/70 bg-background/90 px-5 py-4 backdrop-blur">
            {header}
          </header>
        ) : null}
        <motion.main
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          className={`relative flex-1 px-5 pt-5 ${nav ? "pb-32" : "pb-10"}`}
        >
          {children}
        </motion.main>
        {nav ? <BottomNav /> : null}
      </div>
    </div>
  );
}

export function SectionTitle({
  children,
  action,
  icon,
}: {
  children: ReactNode;
  action?: ReactNode;
  icon?: ReactNode;
}) {
  return (
    <div className="mb-4 flex items-end justify-between gap-3">
      <h2 className="flex items-center gap-2 text-2xl font-bold text-ink">
        {icon}
        {children}
      </h2>
      {action}
    </div>
  );
}

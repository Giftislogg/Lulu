import mixNeonPulse from "@/assets/mix-neon-pulse.jpg";
import coverMidnightDrive from "@/assets/cover-midnight-drive.jpg";
import coverKineticEnergy from "@/assets/cover-kinetic-energy.jpg";
import coverVelocity from "@/assets/cover-velocity.jpg";

export const covers = {
  mix: mixNeonPulse,
  midnightDrive: coverMidnightDrive,
  kinetic: coverKineticEnergy,
  velocity: coverVelocity,
};

export type Track = {
  id: string;
  title: string;
  artist: string;
  cover: string;
  sync?: string;
};

export const recentlyPlayed: Track[] = [
  { id: "r1", title: "Midnight Drive", artist: "Synth Cartel", cover: covers.midnightDrive },
  { id: "r2", title: "Kinetic Energy", artist: "DJ Vector", cover: covers.kinetic },
  { id: "r3", title: "Velocity", artist: "The Accelerators", cover: covers.velocity },
];

export const turboPicks: Track[] = [
  { id: "t1", title: "Overdrive", artist: "Sonic Syndicate", cover: covers.kinetic, sync: "0.2S" },
  {
    id: "t2",
    title: "Hyperloop",
    artist: "Grid Runners",
    cover: covers.midnightDrive,
    sync: "0.4S",
  },
  { id: "t3", title: "Clarity", artist: "White Noise", cover: covers.velocity, sync: "0.1S" },
];

export const trending = [
  { id: "n1", title: "Neon Drift", streams: "24K Streams", cover: covers.midnightDrive },
  { id: "n2", title: "Vortex Pulse", streams: "18K Streams", cover: covers.kinetic },
  { id: "n3", title: "Chrome Bloom", streams: "12K Streams", cover: covers.velocity },
];

export const searchResults = [
  {
    id: "s1",
    title: "Neon Genesis (Extended Mix)",
    artist: "CyberMancer",
    quality: "320kbps",
    size: "8.4MB",
    sync: "0.4s sync",
    cover: covers.midnightDrive,
  },
  {
    id: "s2",
    title: "Nightcall Stems Pack",
    artist: "Kavinsky_Remix",
    quality: "24-bit WAV",
    size: "42.1MB",
    sync: "1.2s sync",
    cover: covers.velocity,
  },
  {
    id: "s3",
    title: "Arcade Sunset Loop",
    artist: "PixelDrive",
    quality: "320kbps",
    size: "6.2MB",
    sync: "0.3s sync",
    cover: covers.kinetic,
  },
];

export const activeSync = [
  {
    id: "a1",
    title: "Cybernetic Rush",
    artist: "Neon Vortex",
    speed: "4.2 MB/s",
    progress: 68,
    cover: covers.kinetic,
  },
  {
    id: "a2",
    title: "Velocity Protocol",
    artist: "DataStream",
    speed: "3.8 MB/s",
    progress: 24,
    cover: covers.velocity,
  },
];

export const completed: Track[] = [
  {
    id: "c1",
    title: "Blinding Lights",
    artist: "The Weeknd",
    cover: "https://i.scdn.co/image/ab67616d0000b27388638622e2004b9e30a43651",
  },
  {
    id: "c2",
    title: "As It Was",
    artist: "Harry Styles",
    cover: "https://i.scdn.co/image/ab67616d0000b273b46f74097655d0f353caab14",
  },
  {
    id: "c3",
    title: "Flowers",
    artist: "Miley Cyrus",
    cover: "https://i.scdn.co/image/ab67616d0000b273f429549123d038222b3145d2",
  },
];

# Lumi: Your Music Companion

i want you to use the exact screen shots to bulid a mobile application called lumi is an intelligent Android music player and system-wide audio assistant designed for seamless music discovery, offline playback, and quick floating overlay controls.

Core Capabilities & Features

Offline Music Downloader & Library:

Allows users to download full audio tracks, albums, and playlists directly to local device storage.

Features a dedicated Offline Download Center and My Library space where downloaded music can be played anytime without an active internet connection.

System-Wide Pop-Up Overlay (Lumi Overlay Mode):

When enabled, Lumii runs an active floating system overlay that stays accessible over top of any other Android app (social media, games, browser, etc.).

Users can search, preview, and control audio on the fly without minimizing or switching away from their current application.

Hardware Shortcut Triggers (Volume Controls):

Integrates with Android physical volume keys (e.g., double-pressing Volume Up or Volume Down).

Automatically summons the Lumi floating orb, voice search listener, or quick music controller wherever you are on your phone.

Voice Search & Instant Discovery:

Built-in voice search mode ("Listen") that analyzes natural speech prompts or song queries in real-time to play or download music instantly through the overlay.

Smart Music Management:

Tracks play history, automatically organizes playlists and favorite tracks, and keeps offline storage organized.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/8c217b08-8df8-4c57-9c66-9938f222210e).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

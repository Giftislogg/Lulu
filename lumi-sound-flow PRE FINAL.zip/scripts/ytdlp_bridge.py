#!/usr/bin/env python3
"""
CLI JSON bridge between Node.js / TanStack server and yt-dlp Python engine.
Provides high-performance music search, metadata extraction, and track discovery.
"""

import sys
import os
import re
import json
import argparse
from pathlib import Path

# Python 3.10 compatibility shims for yt-dlp
if sys.version_info < (3, 11):
    sys.version_info = (3, 11, 0, 'final', 0)
if not hasattr(re, 'NOFLAG'):
    re.NOFLAG = 0
if not hasattr(sys, 'exception'):
    sys.exception = lambda: sys.exc_info()[1]

# Ensure yt-dlp-master is on python path
repo_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(repo_root / "yt-dlp-master"))

try:
    from yt_dlp import YoutubeDL
except ImportError as e:
    print(json.dumps({"error": f"Failed to import yt_dlp from yt-dlp-master: {e}"}))
    sys.exit(1)


def clean_track_name(text):
    if not text:
        return ""
    # Strip common music video tags
    cleaned = re.sub(
        r'\s*[\(\[](?:Official\s*(?:Music\s*)?(?:Video|Audio|Lyric\s*Video|Track)?|Lyric\s*Video|Lyrics|Visualizer|HD|4K|HQ|Audio|Remastered)[\)\]]',
        '',
        text,
        flags=re.IGNORECASE
    )
    # Deduplicate repeated "ft." or "feat."
    cleaned = re.sub(r'(\b(?:ft\.?|feat\.?)\s+[^,\(\)]+)\s+\1', r'\1', cleaned, flags=re.IGNORECASE)
    return cleaned.strip()


def parse_artist_title(title, uploader):
    """
    Parses 'Artist - Title' convention common in music releases,
    falling back to uploader as artist.
    """
    cleaned_title = clean_track_name(title)
    
    if " - " in cleaned_title:
        parts = cleaned_title.split(" - ", 1)
        artist = clean_track_name(parts[0])
        track_title = clean_track_name(parts[1])
        return artist, track_title
    elif " – " in cleaned_title: # en-dash
        parts = cleaned_title.split(" – ", 1)
        artist = clean_track_name(parts[0])
        track_title = clean_track_name(parts[1])
        return artist, track_title
    elif " — " in cleaned_title: # em-dash
        parts = cleaned_title.split(" — ", 1)
        artist = clean_track_name(parts[0])
        track_title = clean_track_name(parts[1])
        return artist, track_title
    else:
        # Fallback to uploader as artist
        clean_uploader = re.sub(r'\s*-\s*Topic$', '', uploader or 'Artist', flags=re.IGNORECASE).strip()
        return clean_uploader, cleaned_title


def format_yt_entry(entry):
    video_id = entry.get("id") or ""
    raw_title = entry.get("title") or "Untitled Track"
    uploader = entry.get("uploader") or entry.get("channel") or "Unknown Artist"
    
    artist, title = parse_artist_title(raw_title, uploader)

    # Duration in seconds
    duration_s = entry.get("duration")
    if duration_s is None or duration_s <= 0:
        duration_s = 180 # default 3 mins if missing
    
    duration_ms = int(duration_s * 1000)
    duration_min = int(duration_s // 60)
    duration_sec = int(duration_s % 60)
    duration_str = f"{duration_min}:{duration_sec:02d}"

    # Calculate estimated file size at 320kbps
    size_mb = round((duration_s * (320 / 8)) / 1024, 1)
    size_str = f"{size_mb}MB"

    # Select best thumbnail
    thumbnails = entry.get("thumbnails") or []
    cover = None
    if thumbnails:
        cover = thumbnails[-1].get("url")
    if not cover:
        cover = entry.get("thumbnail")
    if not cover and video_id:
        cover = f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg"
    if not cover:
        cover = "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?auto=format&fit=crop&w=600&q=80"

    webpage_url = entry.get("url") or entry.get("webpage_url") or f"https://www.youtube.com/watch?v={video_id}"
    if video_id and not str(webpage_url).startswith("http"):
        webpage_url = f"https://www.youtube.com/watch?v={video_id}"

    return {
        "id": f"ytdlp_{video_id}",
        "raw_id": video_id,
        "title": title or "Untitled Track",
        "artist": artist or "Unknown Artist",
        "artists": [artist or "Unknown Artist"],
        "cover": cover,
        "quality": "320kbps HQ (yt-dlp)",
        "size": size_str,
        "sync": f"{round(0.1 + (len(title) % 4) * 0.1, 1)}s sync",
        "duration": duration_str,
        "duration_ms": duration_ms,
        "preview_url": entry.get("direct_audio_url"),
        "url": webpage_url,
        "uri": f"ytdlp:track:{video_id}",
        "explicit": False,
        "engine": "yt-dlp",
        "uploader": uploader,
    }


def search_ytdlp(query, limit=15):
    ydl_opts = {
        'quiet': True,
        'no_warnings': True,
        'extract_flat': True,
        'skip_download': True,
        'ignoreerrors': True,
        'default_search': f'ytsearch{limit}',
    }

    search_term = f"ytsearch{limit}:{query}"
    
    with YoutubeDL(ydl_opts) as ydl:
        try:
            res = ydl.extract_info(search_term, download=False)
            entries = res.get('entries', []) if res else []
            tracks = []
            for item in entries:
                if item:
                    tracks.append(format_yt_entry(item))
            
            # Construct albums & artists representations
            albums = []
            artists = []
            seen_artists = set()

            for idx, t in enumerate(tracks[:4]):
                albums.append({
                    "id": f"alb_ytdlp_{idx}",
                    "title": f"{t['title']} (Album)",
                    "artist": t["artist"],
                    "cover": t["cover"],
                    "url": t["url"],
                })

            for idx, t in enumerate(tracks):
                art_name = t["artist"]
                if art_name not in seen_artists:
                    seen_artists.add(art_name)
                    artists.append({
                        "id": f"art_ytdlp_{len(artists)}",
                        "name": art_name,
                        "cover": t["cover"],
                        "url": t["url"],
                    })
                if len(artists) >= 4:
                    break

            return {
                "query": query,
                "tracks": tracks,
                "albums": albums,
                "artists": artists,
                "total": len(tracks),
                "engine": "yt-dlp",
            }
        except Exception as e:
            return {
                "query": query,
                "tracks": [],
                "albums": [],
                "artists": [],
                "total": 0,
                "error": str(e),
                "engine": "yt-dlp",
            }


def chart_ytdlp(key="top-50-global", limit=15):
    query_map = {
        "top-50-global": "Top 50 Global Songs 2026 Official Audio",
        "viral-hits": "Viral Hits 2026 Music Audio",
        "synthwave": "Synthwave Cyberpunk Electronic Mix 2026",
        "chillhop": "Lofi Chill Beats Study Music 2026",
    }
    query = query_map.get(key, f"{key} Music Top Hits")
    res = search_ytdlp(query, limit=limit)
    return {
        "id": key,
        "title": key.replace("-", " ").title(),
        "tracks": res.get("tracks", []),
        "engine": "yt-dlp",
    }


def track_ytdlp(track_id_or_url):
    ydl_opts = {
        'quiet': True,
        'no_warnings': True,
        'extract_flat': True,
        'skip_download': True,
        'ignoreerrors': True,
    }
    url = track_id_or_url
    if not url.startswith("http"):
        clean_id = track_id_or_url.replace("ytdlp_", "").replace("yt_", "")
        url = f"https://www.youtube.com/watch?v={clean_id}"

    with YoutubeDL(ydl_opts) as ydl:
        try:
            info = ydl.extract_info(url, download=False)
            if info:
                return format_yt_entry(info)
        except Exception as e:
            return {"error": str(e)}
    return {"error": "Track not found"}


def main():
    parser = argparse.ArgumentParser(description="Lumi yt-dlp Engine CLI Bridge")
    subparsers = parser.add_subparsers(dest="command")

    p_search = subparsers.add_parser("search")
    p_search.add_argument("query", type=str, help="Search query")
    p_search.add_argument("--limit", type=int, default=15)

    p_chart = subparsers.add_parser("chart")
    p_chart.add_argument("--key", type=str, default="top-50-global")
    p_chart.add_argument("--limit", type=int, default=15)

    p_track = subparsers.add_parser("track")
    p_track.add_argument("id", type=str, help="Track ID or URL")

    args = parser.parse_args()

    if args.command == "search":
        print(json.dumps(search_ytdlp(args.query, args.limit)))
    elif args.command == "chart":
        print(json.dumps(chart_ytdlp(args.key, args.limit)))
    elif args.command == "track":
        print(json.dumps(track_ytdlp(args.id)))
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()

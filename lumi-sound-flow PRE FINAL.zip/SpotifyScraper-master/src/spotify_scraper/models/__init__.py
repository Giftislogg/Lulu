"""Typed, immutable models for public Spotify entities."""

from __future__ import annotations

from spotify_scraper.models.account import Account
from spotify_scraper.models.album import Album
from spotify_scraper.models.artist import Artist
from spotify_scraper.models.canvas import Canvas
from spotify_scraper.models.colors import Colors
from spotify_scraper.models.common import AlbumRef, ArtistRef, Image, ShowRef, UserRef
from spotify_scraper.models.concert import Concert
from spotify_scraper.models.credits import CreditArtist, CreditRole, Credits
from spotify_scraper.models.episode import Episode
from spotify_scraper.models.lyrics import Lyrics, LyricsLine
from spotify_scraper.models.playlist import Playlist, PlaylistTrack
from spotify_scraper.models.search import SearchResults
from spotify_scraper.models.show import Show
from spotify_scraper.models.track import Track
from spotify_scraper.models.transcript import Transcript, TranscriptLine
from spotify_scraper.models.user import UserProfile

__all__ = [
    "Account",
    "Album",
    "AlbumRef",
    "Artist",
    "ArtistRef",
    "Canvas",
    "Colors",
    "Concert",
    "CreditArtist",
    "CreditRole",
    "Credits",
    "Episode",
    "Image",
    "Lyrics",
    "LyricsLine",
    "Playlist",
    "PlaylistTrack",
    "SearchResults",
    "Show",
    "ShowRef",
    "Track",
    "Transcript",
    "TranscriptLine",
    "UserProfile",
    "UserRef",
]

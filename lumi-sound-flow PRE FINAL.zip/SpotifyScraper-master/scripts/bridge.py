#!/usr/bin/env python3
"""
CLI JSON bridge between Node.js frontend and SpotifyScraper Python engine.
"""

import sys
import json
import argparse
from pathlib import Path

# Ensure package is on sys.path if not installed
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

try:
    from spotify_scraper import SpotifyClient, CacheConfig, FileCache, RetryPolicy
except ImportError as e:
    print(json.dumps({"error": f"Failed to import spotify_scraper: {e}"}))
    sys.exit(1)


def get_client() -> SpotifyClient:
    cache_dir = Path("/tmp/spotify_scraper_cache")
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache = CacheConfig(store=FileCache(cache_dir), ttl_seconds=3600)
    retry = RetryPolicy(max_attempts=3, backoff_base=0.5)
    return SpotifyClient(cache=cache, retry=retry)


def format_track(track):
    images = getattr(track, "images", ())
    cover = images[0].url if images and len(images) > 0 else ""
    if not cover and getattr(track, "album", None) and getattr(track.album, "images", None):
        album_imgs = track.album.images
        if album_imgs and len(album_imgs) > 0:
            cover = album_imgs[0].url

    artists = [a.name for a in getattr(track, "artists", [])]
    artist_str = ", ".join(artists) if artists else "Unknown Artist"

    duration_ms = getattr(track, "duration_ms", 0) or 0
    duration_min = duration_ms // 60000
    duration_sec = (duration_ms % 60000) // 1000
    duration_str = f"{duration_min}:{duration_sec:02d}"

    # Calculate an estimated size based on 320kbps MP3 (approx 2.4MB per min)
    size_mb = round((duration_ms / 1000) * (320 / 8) / 1024, 1) if duration_ms else 5.0
    size_str = f"{size_mb}MB"

    return {
        "id": getattr(track, "id", ""),
        "title": getattr(track, "name", "Untitled Track"),
        "artist": artist_str,
        "artists": artists,
        "cover": cover or "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?auto=format&fit=crop&w=600&q=80",
        "quality": "320kbps HQ",
        "size": size_str,
        "sync": f"{round(0.2 + (len(track.name) % 5) * 0.1, 1)}s sync",
        "duration": duration_str,
        "duration_ms": duration_ms,
        "preview_url": getattr(track, "preview_url", None),
        "url": getattr(track, "url", ""),
        "uri": getattr(track, "uri", ""),
        "explicit": getattr(track, "explicit", False),
    }


def cmd_search(args):
    query = args.query
    limit = args.limit
    types = args.type.split(",") if args.type else ["track"]

    with get_client() as client:
        res = client.search(query, types=types, limit=limit)
        
        tracks = [format_track(t) for t in getattr(res, "tracks", ())]
        
        albums = []
        for alb in getattr(res, "albums", ()):
            imgs = getattr(alb, "images", ())
            cover = imgs[0].url if imgs else ""
            albums.append({
                "id": getattr(alb, "id", ""),
                "title": getattr(alb, "name", ""),
                "artist": ", ".join([a.name for a in getattr(alb, "artists", [])]),
                "cover": cover,
                "url": getattr(alb, "url", ""),
            })

        artists = []
        for art in getattr(res, "artists", ()):
            imgs = getattr(art, "images", ())
            cover = imgs[0].url if imgs else ""
            artists.append({
                "id": getattr(art, "id", ""),
                "name": getattr(art, "name", ""),
                "cover": cover,
                "url": getattr(art, "url", ""),
            })

        print(json.dumps({
            "query": query,
            "tracks": tracks,
            "albums": albums,
            "artists": artists,
            "total": getattr(res, "total", len(tracks))
        }))


def cmd_track(args):
    with get_client() as client:
        track = client.get_track(args.id)
        print(json.dumps(format_track(track)))


def cmd_chart(args):
    key = args.key
    with get_client() as client:
        try:
            playlist = client.get_chart(key, max_tracks=args.limit)
            tracks = []
            for ptrk in getattr(playlist, "tracks", ()):
                if hasattr(ptrk, "track") and ptrk.track:
                    tracks.append(format_track(ptrk.track))
                elif hasattr(ptrk, "name"):
                    tracks.append(format_track(ptrk))
            print(json.dumps({
                "id": playlist.id,
                "title": playlist.name,
                "tracks": tracks
            }))
        except Exception as e:
            # Fallback search if chart unavailable
            res = client.search("Top Hits", types=["track"], limit=args.limit)
            tracks = [format_track(t) for t in getattr(res, "tracks", ())]
            print(json.dumps({
                "id": "top-hits",
                "title": "Top Hits",
                "tracks": tracks
            }))


def main():
    parser = argparse.ArgumentParser(description="SpotifyScraper Bridge CLI")
    subparsers = parser.add_subparsers(dest="command")

    # Search subcommand
    p_search = subparsers.add_parser("search")
    p_search.add_argument("query", type=str, help="Search query string")
    p_search.add_argument("--limit", type=int, default=15)
    p_search.add_argument("--type", type=str, default="track,album,artist")

    # Track subcommand
    p_track = subparsers.add_parser("track")
    p_track.add_argument("id", type=str, help="Track ID or URL")

    # Chart subcommand
    p_chart = subparsers.add_parser("chart")
    p_chart.add_argument("--key", type=str, default="top-50-global")
    p_chart.add_argument("--limit", type=int, default=10)

    args = parser.parse_args()

    if args.command == "search":
        cmd_search(args)
    elif args.command == "track":
        cmd_track(args)
    elif args.command == "chart":
        cmd_chart(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
